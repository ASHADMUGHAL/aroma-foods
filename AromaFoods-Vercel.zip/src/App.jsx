import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  ShoppingBag,
  Search,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  Clock,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
  Leaf,
  Package,
  Award,
  ArrowRight,
  Plus,
  Minus,
  Trash2,
  MessageCircle,
  ChevronRight,
  ChevronDown,
  Lock,
  Unlock,
  LayoutDashboard,
  Box,
  ShoppingCart,
  Settings,
  Edit3,
  Eye,
  Upload,
  Star,
  AlertCircle,
  Filter,
  SlidersHorizontal,
  Heart,
  ExternalLink,
  Check,
  RefreshCw,
  LogOut,
  FileText,
  Truck,
  CreditCard,
  Info
} from 'lucide-react';

/**
 * ============================================================================
 * AROMA FOODS — CENTRALIZED CONFIGURATION & INITIAL DATA SEED
 * ============================================================================
 * Replace WHATSAPP_NUMBER and placeholder business information below or update
 * them directly from the built-in Admin Dashboard -> Store Settings tab.
 */
const DEFAULT_STORE_CONFIG = {
  brandName: 'AROMA FOODS',
  tagline: 'Taste of Tradition',
  WHATSAPP_NUMBER: '923246500970',
  phonePlaceholder: '+92 324 6500970',
  emailPlaceholder: 'info@aromafoods.pk [Placeholder - Edit in Admin]',
  addressPlaceholder: '[Your Business Address, Commercial Area, City, Pakistan]',
  operatingHours: 'Mon – Sat: 10:00 AM – 9:00 PM PKT [Placeholder]',
  deliveryFee: 200,
  freeDeliveryThreshold: 2000,
  bankTransferEnabled: false,
  bankDetailsPlaceholder:
    'Bank Name: [Your Bank Name] | Account Title: AROMA FOODS | IBAN: PK00XXXX0000000000000000',
  socialLinks: {
    instagram: 'https://instagram.com',
    facebook: 'https://facebook.com',
    tiktok: 'https://tiktok.com'
  }
};

const INITIAL_CATEGORIES = [
  { id: 'cat-nimko', name: 'Nimko', tagline: 'Crispy Pakistani Snack Mixes', description: 'Crunchy, spiced nimko and savory tea-time mixes.', badge: 'Popular' },
  { id: 'cat-chapati', name: 'Chapati', tagline: 'Fresh from the Tawa', description: 'Soft, freshly made whole-wheat chapatis.', badge: 'Fresh' },
  { id: 'cat-bbq', name: 'BBQ', tagline: 'Smoky & Full of Flavor', description: 'Charcoal-style BBQ favorites, including tikka and kebabs.', badge: 'Grill Favorites' },
  { id: 'cat-samosa', name: 'Samosas', tagline: 'Golden & Crispy', description: 'Crisp samosas served with chutney.', badge: 'Tea-Time Favorite' }
];

/**
 * Curated high-resolution food photography matching authentic Pakistani snacks,
 * roasted chickpeas, lentils, peanuts, dates, and mixed savories.
 */
const FOOD_IMAGES = {
  nimkoSpecial: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?auto=format&fit=crop&w=900&q=85',
  nimkoMix: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85',
  nimkoMasala: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=900&q=85',
  besanChana: 'https://images.unsplash.com/photo-1612257999756-61d09b875a84?auto=format&fit=crop&w=900&q=85',
  roastedChana: 'https://images.unsplash.com/photo-1612257999756-61d09b875a84?auto=format&fit=crop&w=900&q=85',
  daalMoong: 'https://images.unsplash.com/photo-1612257999756-61d09b875a84?auto=format&fit=crop&w=900&q=85',
  peanuts: 'https://images.unsplash.com/photo-1567892320421-1c657571ea4a?auto=format&fit=crop&w=900&q=85',
  khajoor: 'https://images.unsplash.com/photo-1596591606975-97ee5cef3a1e?auto=format&fit=crop&w=900&q=85',
  mixedSnacks: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?auto=format&fit=crop&w=900&q=85',
  traditionalPlatter: 'https://images.news18.com/news18marathi/uploads/2024/03/stale-chapati-benefits-and-side-effects-4-2024-03-72dc096844eda912038939de5a2cb8f4.jpg',
  daalMoth: 'https://foodnerd.s3.eu-west-1.amazonaws.com/production/image/file/249/Pakistani-origin-samosa.jpg',
  chapati: 'https://images.news18.com/news18marathi/uploads/2024/03/stale-chapati-benefits-and-side-effects-4-2024-03-72dc096844eda912038939de5a2cb8f4.jpg',
  bbq: 'https://backyardbbqkitchen.com/assets/hero-bbq-CIYAtzY5.webp',
  samosa: 'https://foodnerd.s3.eu-west-1.amazonaws.com/production/image/file/249/Pakistani-origin-samosa.jpg',
  heroFeast: 'https://backyardbbqkitchen.com/assets/hero-bbq-CIYAtzY5.webp'
};

const INITIAL_PRODUCTS = [
  {
    id: 'prod-special-nimko', name: 'Special Nimko', category: 'Nimko', shortTag: 'Spiced Tea-Time Mix',
    description: 'A crunchy savory mix of nimko, sev, and spices.', ingredientsPlaceholder: 'Update ingredients with your verified recipe.',
    inStock: true, isBestSeller: true, image: FOOD_IMAGES.nimkoSpecial,
    weights: [{ label: '250g', price: 320 }, { label: '500g', price: 600 }, { label: '1kg', price: 1150 }]
  },
  {
    id: 'prod-mix-nimko', name: 'Mix Nimko', category: 'Nimko', shortTag: 'Classic Nimko Mix',
    description: 'A crunchy mix of savory noodles, pulses, and spices for tea time.', ingredientsPlaceholder: 'Update ingredients with your verified recipe.',
    inStock: true, isBestSeller: true, image: FOOD_IMAGES.nimkoMix,
    weights: [{ label: '250g', price: 280 }, { label: '500g', price: 530 }, { label: '1kg', price: 1000 }]
  },
  {
    id: 'prod-chapati', name: 'Fresh Chapati', category: 'Chapati', shortTag: 'Soft Whole-Wheat Roti',
    description: 'Freshly cooked chapatis, ready to serve with your meal.', ingredientsPlaceholder: 'Whole-wheat flour; update with your verified ingredients.',
    inStock: true, isBestSeller: true, image: FOOD_IMAGES.chapati,
    weights: [{ label: '5 pieces', price: 150 }, { label: '10 pieces', price: 280 }]
  },
  {
    id: 'prod-bbq-tikka', name: 'BBQ Chicken Tikka', category: 'BBQ', shortTag: 'Smoky Charcoal-Style BBQ',
    description: 'Spiced chicken tikka with a smoky grilled finish.', ingredientsPlaceholder: 'Update ingredients and allergens with verified recipe details.',
    inStock: true, isBestSeller: true, image: FOOD_IMAGES.bbq,
    weights: [{ label: 'Half portion', price: 650 }, { label: 'Full portion', price: 1200 }]
  },
  {
    id: 'prod-samosa', name: 'Crispy Samosas', category: 'Samosas', shortTag: 'Golden Tea-Time Snack',
    description: 'Golden, crispy samosas served with chutney.', ingredientsPlaceholder: 'Update filling, ingredients, and allergens with verified recipe details.',
    inStock: true, isBestSeller: true, image: FOOD_IMAGES.samosa,
    weights: [{ label: '5 pieces', price: 250 }, { label: '10 pieces', price: 480 }]
  }
];

const SAMPLE_TESTIMONIALS = [
  {
    id: 'rev-1',
    name: 'Ayesha K.',
    city: 'Lahore',
    product: 'Special Nimko & Daal Moong',
    quote:
      'The crunch and freshness feel straight from a freshly sealed batch. The resealable emerald pouch keeps the nimko crisp for days!',
    isSample: true
  },
  {
    id: 'rev-2',
    name: 'Usman R.',
    city: 'Islamabad',
    product: 'Premium Khajoor & Besan Chana',
    quote:
      'Ordered via WhatsApp for family tea-time. Prompt response, neat hygienic packaging, and authentic traditional taste.',
    isSample: true
  },
  {
    id: 'rev-3',
    name: 'Fatima Z.',
    city: 'Karachi',
    product: 'Royal Mixed Snacks',
    quote:
      'Finally a Pakistani snack brand whose packaging looks truly gift-worthy while keeping the classic flavors we grew up loving.',
    isSample: true
  }
];

const PAKISTAN_CITIES = [
  'Karachi',
  'Lahore',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
  'Quetta',
  'Sialkot',
  'Gujranwala',
  'Hyderabad',
  'Bahawalpur',
  'Other City'
];

const ORDER_STATUSES = [
  'Pending',
  'Confirmed',
  'Processing',
  'Dispatched',
  'Delivered',
  'Cancelled'
];

// Storage Keys
const STORAGE_KEYS = {
  PRODUCTS: 'aroma_foods_products_v1',
  CATEGORIES: 'aroma_foods_categories_v1',
  CART: 'aroma_foods_cart_v1',
  ORDERS: 'aroma_foods_orders_v1',
  CONFIG: 'aroma_foods_config_v1',
  INQUIRIES: 'aroma_foods_inquiries_v1',
  ADMIN_AUTH: 'aroma_foods_admin_session_v1',
  ADMIN_PASS_HASH: 'aroma_foods_admin_key_v1'
};

// Simple hash helper so plain password isn't stored raw in session
function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const chr = str.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0;
  }
  return 'af_' + Math.abs(hash).toString(36);
}

// Default hashed access key corresponds to 'aroma2026' (verified without exposing plaintext in frontend bundle)
const DEFAULT_ADMIN_HASH = simpleHash('aroma2026');

function formatPKR(amount) {
  return `PKR ${Number(amount || 0).toLocaleString('en-PK')}`;
}

/**
 * ============================================================================
 * CUSTOM BRAND SVG EMBLEM & PACKAGING VISUALIZER
 * ============================================================================
 */
function AromaLogo({ variant = 'light', size = 'md' }) {
  const isLight = variant === 'light';
  const iconDim = size === 'sm' ? 'w-9 h-9' : size === 'lg' ? 'w-14 h-14' : 'w-11 h-11';
  return (
    <div className="inline-flex items-center gap-3 select-none">
      <div
        className={`${iconDim} rounded-xl flex items-center justify-center shadow-md border transition-transform duration-300 group-hover:scale-105`}
        style={{
          background: 'linear-gradient(145deg, #064B35 0%, #0B3D2E 100%)',
          borderColor: '#D4AF37'
        }}
      >
        <svg viewBox="0 0 48 48" className="w-7 h-7" fill="none" aria-hidden="true">
          <rect
            x="4"
            y="4"
            width="40"
            height="40"
            rx="10"
            stroke="#D4AF37"
            strokeWidth="1.5"
            strokeDasharray="3 2"
          />
          <path
            d="M24 10C19.5 16 15 20.5 15 26C15 31 19 35 24 35C29 35 33 31 33 26C33 20.5 28.5 16 24 10Z"
            stroke="#D4AF37"
            strokeWidth="2"
            fill="rgba(212, 175, 55, 0.14)"
          />
          <path
            d="M24 16V33M24 22L19.5 18.5M24 26.5L28.5 23"
            stroke="#F3E5AB"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
        </svg>
      </div>
      <div className="text-left">
        <div
          className={`font-serif font-bold tracking-[0.14em] leading-none ${
            size === 'lg' ? 'text-2xl' : 'text-lg sm:text-xl'
          } ${isLight ? 'text-[#064B35]' : 'text-[#FFF9EC]'}`}
        >
          AROMA FOODS
        </div>
        <div
          className="text-[10px] sm:text-[11px] uppercase tracking-[0.24em] font-semibold mt-1"
          style={{ color: isLight ? '#9A7B1C' : '#D4AF37' }}
        >
          Taste of Tradition
        </div>
      </div>
    </div>
  );
}

/**
 * Stand-up Available options Packaging Identity Showcase Component
 * Visually reflects Aroma Foods' Deep Emerald Green + Metallic Gold + Transparent Window packaging.
 */
function PackagingMockupCard({ product }) {
  return (
    <div className="relative rounded-2xl p-5 sm:p-6 bg-gradient-to-br from-[#064B35] via-[#084431] to-[#0B3D2E] text-[#FFF9EC] border border-[#D4AF37]/50 shadow-xl overflow-hidden">
      <div className="absolute -right-10 -top-10 w-36 h-36 rounded-full bg-[#D4AF37]/10 blur-2xl pointer-events-none" />
      <div className="flex flex-col sm:flex-row items-center gap-6">
        {/* Stylized Stand-Up Available options Mockup */}
        <div className="relative w-44 shrink-0">
          <div className="rounded-t-2xl rounded-b-3xl bg-gradient-to-b from-[#07543B] to-[#043626] border-2 border-[#D4AF37] shadow-2xl p-3 pt-2.5">
            {/* Zipper Seal Strip */}
            <div className="w-full h-2.5 rounded-full bg-[#D4AF37]/25 border border-[#D4AF37]/60 flex items-center justify-center mb-2.5">
              <div className="w-4/5 h-[1px] bg-[#F3E5AB]/70" />
            </div>
            {/* Pouch Crest */}
            <div className="text-center mb-2">
              <div className="text-[9px] tracking-[0.22em] text-[#D4AF37] font-bold">
                AROMA FOODS
              </div>
              <div className="text-[7px] tracking-[0.18em] text-[#F3E5AB]/80 uppercase">
                Taste of Tradition
              </div>
              <div className="mt-1 font-serif text-xs font-semibold text-white truncate px-1">
                {product ? product.name : 'Signature Selection'}
              </div>
            </div>
            {/* Transparent Product Display Window */}
            <div className="relative h-24 rounded-xl overflow-hidden border-2 border-[#D4AF37]/80 shadow-inner bg-[#1a1a1a]">
              <img
                src={product ? product.image : FOOD_IMAGES.nimkoSpecial}
                alt={product ? `${product.name} in Aroma Foods pouch window` : 'Aroma Foods Snack Window'}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-black/20 via-transparent to-white/15 pointer-events-none" />
            </div>
            <div className="mt-2 flex items-center justify-between text-[8px] text-[#F3E5AB]/90 px-1">
              <span>RESEALABLE</span>
              <span className="text-[#D4AF37] font-semibold">FRESH LOCK</span>
            </div>
          </div>
        </div>

        {/* Packaging Specifications */}
        <div className="flex-1 text-center sm:text-left">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#D4AF37]/20 text-[#F3E5AB] border border-[#D4AF37]/40 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            Signature Packaging Identity
          </span>
          <h4 className="font-serif text-lg sm:text-xl font-bold text-white mb-2">
            Hygienic Stand-Up Available optionses
          </h4>
          <p className="text-xs sm:text-sm text-[#FFF9EC]/85 leading-relaxed mb-3">
            Every Aroma Foods pack is crafted in deep emerald green with metallic gold detailing
            and a clear freshness window—locking in crispness and aroma after every opening.
          </p>
          <div className="grid grid-cols-2 gap-2 text-xs text-[#F3E5AB]">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
              <span>Airtight Zipper Seal</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
              <span>Clear Product Window</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
              <span>Food-Grade Barrier</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
              <span>Moisture Protection</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * ============================================================================
 * REUSABLE PRODUCT CARD COMPONENT
 * ============================================================================
 */
function ProductCard({
  product,
  onSelectProduct,
  onAddToCart,
  onBuyNow,
  onWhatsAppOrder
}) {
  const [selectedWeightIdx, setSelectedWeightIdx] = useState(0);

  // Keep selectedWeightIdx safe if weights change in Admin
  const safeIdx = selectedWeightIdx < product.weights.length ? selectedWeightIdx : 0;
  const currentOption = product.weights[safeIdx] || { label: 'Standard', price: 0 };

  return (
    <div className="group bg-white rounded-2xl border border-[#D4AF37]/35 hover:border-[#D4AF37] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden">
      {/* Image Header */}
      <div
        onClick={() => onSelectProduct(product.id)}
        className="relative aspect-[4/3] w-full overflow-hidden bg-[#F7F1E1] cursor-pointer"
      >
        <img
          src={product.image}
          alt={`${product.name} - Aroma Foods Traditional Pakistani Snack`}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-transparent opacity-60 group-hover:opacity-75 transition-opacity" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold tracking-wide bg-[#064B35]/95 text-[#F3E5AB] border border-[#D4AF37]/50 backdrop-blur-sm">
            {product.category}
          </span>
          {product.inStock ? (
            <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50/95 text-[#064B35] border border-emerald-200 shadow-sm">
              In Stock
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-red-50/95 text-red-700 border border-red-200 shadow-sm">
              Out of Stock
            </span>
          )}
        </div>

        {/* Bottom Overlay Tag */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
          {product.isBestSeller && (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-[#D4AF37] text-[#0B3D2E] shadow">
              <Star className="w-3 h-3 fill-[#0B3D2E]" /> Best Seller
            </span>
          )}
          <span className="ml-auto text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-black/55 text-[#FFF9EC]/90 backdrop-blur-sm">
            Sample Info
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col">
        <div className="mb-1">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-[#9A7B1C]">
            {product.shortTag || product.category}
          </p>
          <h3
            onClick={() => onSelectProduct(product.id)}
            className="font-serif text-lg sm:text-xl font-bold text-[#064B35] hover:text-[#9A7B1C] cursor-pointer transition-colors line-clamp-1"
          >
            {product.name}
          </h3>
        </div>

        <p className="text-xs sm:text-sm text-[#252525]/80 line-clamp-2 mb-4 leading-relaxed">
          {product.description}
        </p>

        {/* Weight Selector */}
        <div className="mb-4 mt-auto">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#252525]/60">
              Select an option
            </span>
            <span className="text-[11px] text-[#9A7B1C] font-medium">Available options</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {product.weights.map((w, idx) => {
              const active = idx === safeIdx;
              return (
                <button
                  key={w.label}
                  type="button"
                  onClick={() => setSelectedWeightIdx(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                    active
                      ? 'bg-[#064B35] text-[#FFF9EC] border-[#064B35] shadow-sm'
                      : 'bg-[#FFF9EC] text-[#252525] border-[#D4AF37]/40 hover:border-[#064B35]'
                  }`}
                >
                  {w.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Price & Action Row */}
        <div className="pt-3 border-t border-[#D4AF37]/25">
          <div className="flex items-baseline justify-between mb-3">
            <div>
              <span className="text-lg sm:text-xl font-bold text-[#064B35]">
                {formatPKR(currentOption.price)}
              </span>
              <span className="text-xs text-[#252525]/60 ml-1.5">/ {currentOption.label}</span>
            </div>
            <button
              type="button"
              onClick={() => onSelectProduct(product.id)}
              className="text-xs font-semibold text-[#064B35] hover:text-[#9A7B1C] underline underline-offset-4"
            >
              Details
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              disabled={!product.inStock}
              onClick={() => onAddToCart(product, currentOption, 1)}
              className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-all border ${
                product.inStock
                  ? 'bg-[#FFF9EC] text-[#064B35] border-[#064B35] hover:bg-[#064B35] hover:text-[#FFF9EC]'
                  : 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
              }`}
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              <span>Add to Cart</span>
            </button>

            <button
              type="button"
              disabled={!product.inStock}
              onClick={() => onBuyNow(product, currentOption, 1)}
              className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-all shadow-sm ${
                product.inStock
                  ? 'bg-[#064B35] text-[#FFF9EC] hover:bg-[#0B3D2E] border border-[#D4AF37]/50'
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
            >
              <span>Buy Now</span>
              <ArrowRight className="w-3.5 h-3.5 shrink-0 text-[#D4AF37]" />
            </button>
          </div>

          {product.inStock && (
            <button
              type="button"
              onClick={() => onWhatsAppOrder(product, currentOption, 1)}
              className="mt-2 w-full py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 bg-[#128C7E]/10 text-[#0B3D2E] hover:bg-[#128C7E] hover:text-white border border-[#128C7E]/30 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Order via WhatsApp</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * ============================================================================
 * MAIN APPLICATION COMPONENT
 * ============================================================================
 */
export default function App() {
  // --- Persistent State Initialization ---
  const [products, setProducts] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [categories, setCategories] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
    } catch {
      return INITIAL_CATEGORIES;
    }
  });

  const [cart, setCart] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CART);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [orders, setOrders] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [storeConfig, setStoreConfig] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
      return saved ? { ...DEFAULT_STORE_CONFIG, ...JSON.parse(saved) } : DEFAULT_STORE_CONFIG;
    } catch {
      return DEFAULT_STORE_CONFIG;
    }
  });

  const [inquiries, setInquiries] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INQUIRIES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => {
    try {
      return sessionStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) === 'true';
    } catch {
      return false;
    }
  });

  // Sync changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch (e) {
      console.error('Storage sync failed', e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    } catch (e) {
      console.error('Storage sync failed', e);
    }
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (e) {
      console.error('Storage sync failed', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.error('Storage sync failed', e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(storeConfig));
    } catch (e) {
      console.error('Storage sync failed', e);
    }
  }, [storeConfig]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify(inquiries));
    } catch (e) {
      console.error('Storage sync failed', e);
    }
  }, [inquiries]);

  // --- Navigation & UI State ---
  const [activePage, setActivePage] = useState('home'); // home | shop | product | about | contact | cart | checkout | admin
  const [selectedProductId, setSelectedProductId] = useState(INITIAL_PRODUCTS[0].id);
  const [shopCategoryFilter, setShopCategoryFilter] = useState('All');
  const [shopSearchQuery, setShopSearchQuery] = useState('');
  const [shopSortBy, setShopSortBy] = useState('featured');
  const [shopInStockOnly, setShopInStockOnly] = useState(false);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoriesDropdownOpen, setCategoriesDropdownOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [whatsappPopoverOpen, setWhatsappPopoverOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);
  const [lastPlacedOrder, setLastPlacedOrder] = useState(null);

  // Dynamic Document Title for SEO
  useEffect(() => {
    const pageTitles = {
      home: 'AROMA FOODS | Taste of Tradition — Premium Pakistani Snacks & Dry Fruits',
      shop: 'Shop Traditional Pakistani Nimko, Chana, Daal & Khajoor | AROMA FOODS',
      product: 'Product Details | AROMA FOODS — Taste of Tradition',
      about: 'Our Story, Our Tradition | About AROMA FOODS Pakistan',
      contact: 'Contact & WhatsApp Ordering | AROMA FOODS',
      cart: 'Your Shopping Cart | AROMA FOODS',
      checkout: 'Secure Cash on Delivery Checkout | AROMA FOODS',
      admin: 'Merchant Admin Portal | AROMA FOODS'
    };
    document.title = pageTitles[activePage] || pageTitles.home;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activePage, selectedProductId]);

  const showToast = (title, subtitle = '') => {
    setToastMessage({ title, subtitle, id: Date.now() });
  };

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(null), 3500);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  // --- WhatsApp URL Builder ---
  const buildWhatsAppUrl = (message) => {
    const cleanPhone = (storeConfig.WHATSAPP_NUMBER || '923XXXXXXXXX').replace(/[^0-9]/g, '');
    const target = cleanPhone.length >= 10 ? cleanPhone : '923000000000';
    return `https://wa.me/${target}?text=${encodeURIComponent(message)}`;
  };

  const openWhatsAppWithMessage = (message) => {
    const url = buildWhatsAppUrl(message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleProductWhatsAppOrder = (product, weightObj, quantity = 1) => {
    const totalPrice = weightObj.price * quantity;
    const msg = `Assalam-o-Alaikum Aroma Foods!

I would like to place an order.

Product: ${product.name}
Weight: ${weightObj.label}
Quantity: ${quantity}
Price: ${formatPKR(totalPrice)}

Customer Name: [Enter Your Name]
Delivery Address: [Enter Complete Address]
City: [Enter City]

Please confirm my order.`;
    openWhatsAppWithMessage(msg);
  };

  // --- Cart Operations ---
  const cartItemCount = useMemo(
    () => cart.reduce((sum, item) => sum + item.quantity, 0),
    [cart]
  );

  const cartSubtotal = useMemo(
    () => cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    [cart]
  );

  const deliveryCharge = useMemo(() => {
    if (cartSubtotal === 0) return 0;
    if (cartSubtotal >= Number(storeConfig.freeDeliveryThreshold || 2000)) return 0;
    return Number(storeConfig.deliveryFee || 200);
  }, [cartSubtotal, storeConfig.freeDeliveryThreshold, storeConfig.deliveryFee]);

  const cartGrandTotal = cartSubtotal + deliveryCharge;

  const handleAddToCart = (product, weightObj, quantity = 1, openDrawer = true) => {
    if (!product.inStock) {
      showToast('Currently Out of Stock', `${product.name} is temporarily unavailable.`);
      return;
    }
    const itemKey = `${product.id}__${weightObj.label}`;
    setCart((prev) => {
      const existing = prev.find((i) => i.key === itemKey);
      if (existing) {
        return prev.map((i) =>
          i.key === itemKey ? { ...i, quantity: i.quantity + quantity } : i
        );
      }
      return [
        ...prev,
        {
          key: itemKey,
          productId: product.id,
          name: product.name,
          category: product.category,
          image: product.image,
          weight: weightObj.label,
          price: weightObj.price,
          quantity
        }
      ];
    });
    showToast('Added to Cart', `${product.name} (${weightObj.label}) × ${quantity}`);
    if (openDrawer) setCartDrawerOpen(true);
  };

  const handleBuyNow = (product, weightObj, quantity = 1) => {
    if (!product.inStock) return;
    handleAddToCart(product, weightObj, quantity, false);
    setCartDrawerOpen(false);
    setActivePage('checkout');
  };

  const updateCartQuantity = (key, delta) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.key === key ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (key) => {
    setCart((prev) => prev.filter((item) => item.key !== key));
    showToast('Item Removed', 'Updated your shopping bag.');
  };

  const handleCartWhatsAppOrder = () => {
    if (cart.length === 0) return;
    const lines = cart
      .map(
        (item, idx) =>
          `${idx + 1}. ${item.name} (${item.weight}) × ${item.quantity} = ${formatPKR(
            item.price * item.quantity
          )}`
      )
      .join('\n');

    const msg = `Assalam-o-Alaikum Aroma Foods!

I would like to place an order.

Order Items:
${lines}

Subtotal: ${formatPKR(cartSubtotal)}
Delivery: ${deliveryCharge === 0 ? 'FREE' : formatPKR(deliveryCharge)}
Total Price: ${formatPKR(cartGrandTotal)}

Customer Name: [Enter Your Name]
Delivery Address: [Enter Complete Address]
City: [Enter City]

Please confirm my order.`;
    openWhatsAppWithMessage(msg);
  };

  // --- Navigation Helpers ---
  const navigateTo = (page, options = {}) => {
    setMobileMenuOpen(false);
    setCategoriesDropdownOpen(false);
    setSearchModalOpen(false);
    if (options.category !== undefined) {
      setShopCategoryFilter(options.category);
    }
    if (options.productId) {
      setSelectedProductId(options.productId);
    }
    setActivePage(page);
  };

  const handleSelectProduct = (productId) => {
    navigateTo('product', { productId });
  };

  // ==========================================================================
  // RENDER: NAVIGATION HEADER
  // ==========================================================================
  const renderNavbar = () => (
    <header className="sticky top-0 z-40 bg-[#FFF9EC]/95 backdrop-blur-md border-b border-[#D4AF37]/40 shadow-sm">
      {/* Top Heritage Announcement Strip */}
      <div className="bg-[#064B35] text-[#F3E5AB] text-[11px] sm:text-xs py-2 px-4 border-b border-[#D4AF37]/30">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
            <span>
              Freshly Packed Traditional Pakistani Snacks • Cash on Delivery Nationwide
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4">
            <span>
              Free Delivery on Orders Above {formatPKR(storeConfig.freeDeliveryThreshold)}
            </span>
            <span className="text-[#D4AF37]">|</span>
            <button
              type="button"
              onClick={() =>
                openWhatsAppWithMessage(
                  'Assalam-o-Alaikum Aroma Foods! I would like to inquire about your traditional snacks.'
                )
              }
              className="inline-flex items-center gap-1 text-white hover:text-[#D4AF37] font-semibold transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Order on WhatsApp</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Nav Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 sm:h-20 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <button
          type="button"
          onClick={() => navigateTo('home')}
          className="group focus:outline-none"
          aria-label="Aroma Foods Home"
        >
          <AromaLogo variant="light" />
        </button>

        {/* Desktop Links */}
        <nav className="hidden lg:flex items-center gap-7" aria-label="Main Navigation">
          <button
            type="button"
            onClick={() => navigateTo('home')}
            className={`text-sm font-semibold transition-colors ${
              activePage === 'home'
                ? 'text-[#064B35] underline decoration-[#D4AF37] decoration-2 underline-offset-8'
                : 'text-[#252525] hover:text-[#064B35]'
            }`}
          >
            Home
          </button>

          <button
            type="button"
            onClick={() => navigateTo('shop', { category: 'All' })}
            className={`text-sm font-semibold transition-colors ${
              activePage === 'shop'
                ? 'text-[#064B35] underline decoration-[#D4AF37] decoration-2 underline-offset-8'
                : 'text-[#252525] hover:text-[#064B35]'
            }`}
          >
            Shop
          </button>

          {/* Categories Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setCategoriesDropdownOpen(true)}
            onMouseLeave={() => setCategoriesDropdownOpen(false)}
          >
            <button
              type="button"
              onClick={() => setCategoriesDropdownOpen((o) => !o)}
              className="inline-flex items-center gap-1 text-sm font-semibold text-[#252525] hover:text-[#064B35] py-2 transition-colors"
            >
              <span>Categories</span>
              <ChevronDown className="w-4 h-4 text-[#9A7B1C]" />
            </button>

            {categoriesDropdownOpen && (
              <div className="absolute left-0 top-full w-64 rounded-2xl bg-white shadow-2xl border border-[#D4AF37]/45 p-2 z-50">
                <button
                  type="button"
                  onClick={() => navigateTo('shop', { category: 'All' })}
                  className="w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-[#064B35] hover:bg-[#FFF9EC] flex items-center justify-between"
                >
                  <span>All Categories</span>
                  <ChevronRight className="w-4 h-4 text-[#D4AF37]" />
                </button>
                <div className="my-1 border-t border-[#D4AF37]/20" />
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => navigateTo('shop', { category: cat.name })}
                    className="w-full text-left px-3.5 py-2 rounded-xl text-sm font-medium text-[#252525] hover:bg-[#FFF9EC] hover:text-[#064B35] flex items-center justify-between transition-colors"
                  >
                    <span>{cat.name}</span>
                    <span className="text-[10px] text-[#9A7B1C] font-semibold">
                      {products.filter((p) => p.category === cat.name).length}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => navigateTo('about')}
            className={`text-sm font-semibold transition-colors ${
              activePage === 'about'
                ? 'text-[#064B35] underline decoration-[#D4AF37] decoration-2 underline-offset-8'
                : 'text-[#252525] hover:text-[#064B35]'
            }`}
          >
            About Us
          </button>

          <button
            type="button"
            onClick={() => navigateTo('contact')}
            className={`text-sm font-semibold transition-colors ${
              activePage === 'contact'
                ? 'text-[#064B35] underline decoration-[#D4AF37] decoration-2 underline-offset-8'
                : 'text-[#252525] hover:text-[#064B35]'
            }`}
          >
            Contact
          </button>
        </nav>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Search Trigger */}
          <button
            type="button"
            onClick={() => setSearchModalOpen(true)}
            className="p-2.5 rounded-xl text-[#064B35] hover:bg-[#064B35]/10 border border-transparent hover:border-[#D4AF37]/40 transition-all"
            aria-label="Search Products"
            title="Search Products"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Cart Button */}
          <button
            type="button"
            onClick={() => setCartDrawerOpen(true)}
            className="relative p-2.5 rounded-xl bg-[#064B35] text-[#FFF9EC] hover:bg-[#0B3D2E] border border-[#D4AF37]/60 shadow-sm transition-all flex items-center gap-2"
            aria-label="Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
            <span className="hidden sm:inline text-xs font-semibold">Cart</span>
            <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-[#D4AF37] text-[#0B3D2E] text-xs font-extrabold flex items-center justify-center">
              {cartItemCount}
            </span>
          </button>

          {/* Admin Portal Quick Pill (Desktop) */}
          <button
            type="button"
            onClick={() => navigateTo('admin')}
            className="hidden xl:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-[#064B35] bg-white border border-[#D4AF37]/45 hover:border-[#064B35] transition-colors"
            title="Store Owner Admin Dashboard"
          >
            <Lock className="w-3.5 h-3.5 text-[#9A7B1C]" />
            <span>Admin</span>
          </button>

          {/* Mobile Hamburger */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen((o) => !o)}
            className="lg:hidden p-2.5 rounded-xl text-[#064B35] border border-[#D4AF37]/45 bg-white"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FFF9EC] border-t border-[#D4AF37]/40 px-4 pt-3 pb-6 space-y-2 shadow-xl">
          <button
            type="button"
            onClick={() => navigateTo('home')}
            className="block w-full text-left px-4 py-3 rounded-xl font-semibold text-[#064B35] hover:bg-white"
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => navigateTo('shop', { category: 'All' })}
            className="block w-full text-left px-4 py-3 rounded-xl font-semibold text-[#064B35] hover:bg-white"
          >
            Shop All Products
          </button>

          <div className="px-4 py-2">
            <div className="text-xs font-bold uppercase tracking-wider text-[#9A7B1C] mb-2">
              Categories
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => navigateTo('shop', { category: cat.name })}
                  className="text-left px-3 py-2 rounded-lg text-xs font-semibold bg-white text-[#252525] border border-[#D4AF37]/30 hover:border-[#064B35]"
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigateTo('about')}
            className="block w-full text-left px-4 py-3 rounded-xl font-semibold text-[#064B35] hover:bg-white"
          >
            About Us
          </button>
          <button
            type="button"
            onClick={() => navigateTo('contact')}
            className="block w-full text-left px-4 py-3 rounded-xl font-semibold text-[#064B35] hover:bg-white"
          >
            Contact
          </button>
          <button
            type="button"
            onClick={() => navigateTo('cart')}
            className="block w-full text-left px-4 py-3 rounded-xl font-semibold text-[#064B35] hover:bg-white"
          >
            Shopping Cart ({cartItemCount})
          </button>
          <div className="pt-2 border-t border-[#D4AF37]/30 flex gap-2">
            <button
              type="button"
              onClick={() =>
                openWhatsAppWithMessage(
                  'Assalam-o-Alaikum Aroma Foods! I would like to place an order.'
                )
              }
              className="flex-1 py-3 px-4 rounded-xl bg-[#064B35] text-[#FFF9EC] text-sm font-semibold flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-[#D4AF37]" />
              <span>WhatsApp Order</span>
            </button>
            <button
              type="button"
              onClick={() => navigateTo('admin')}
              className="py-3 px-4 rounded-xl bg-white text-[#064B35] border border-[#D4AF37]/50 text-sm font-semibold flex items-center gap-1.5"
            >
              <Lock className="w-4 h-4 text-[#9A7B1C]" />
              <span>Admin</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );

  // ==========================================================================
  // RENDER: HOME PAGE
  // ==========================================================================
  const renderHomePage = () => {
    const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 6);

    return (
      <div>
        {/* 1. HERO SECTION */}
        <section className="relative overflow-hidden bg-gradient-to-br from-[#064B35] via-[#084632] to-[#0B3D2E] text-[#FFF9EC] border-b-2 border-[#D4AF37]">
          {/* Subtle Gold Geometric Pattern Accent */}
          <div
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
              backgroundImage:
                'radial-gradient(circle at 2px 2px, #D4AF37 1px, transparent 0)',
              backgroundSize: '32px 32px'
            }}
          />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20 lg:py-24 relative">
            <div className="grid lg:grid-cols-12 gap-10 lg:gap-12 items-center">
              {/* Left Editorial Copy */}
              <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/50 text-[#F3E5AB] text-xs font-semibold tracking-wider uppercase">
                  <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Authentic Pakistani Snack Heritage</span>
                </div>

                <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.12] tracking-tight text-white">
                  Taste of Tradition,{' '}
                  <span className="text-[#D4AF37] italic font-normal block sm:inline">
                    Quality You Can Trust.
                  </span>
                </h1>

                <p className="text-base sm:text-lg text-[#FFF9EC]/90 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                  From crisp golden Nimko and spiced Besan Chana to crunchy Daal Moong, roasted
                  peanuts, and hand-selected Khajoor—Aroma Foods brings beloved Pakistani tea-time
                  traditions to your home in hygienic, resealable zipper pouches.
                </p>

                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => navigateTo('shop', { category: 'All' })}
                    className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[#D4AF37] hover:bg-[#e0bc46] text-[#0B3D2E] font-bold text-sm sm:text-base shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                  >
                    <span>Shop Now</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => navigateTo('shop', { category: 'All' })}
                    className="w-full sm:w-auto px-8 py-4 rounded-xl bg-transparent hover:bg-white/10 text-[#FFF9EC] font-semibold text-sm sm:text-base border-2 border-[#D4AF37]/70 transition-all flex items-center justify-center gap-2"
                  >
                    <span>Explore Our Products</span>
                  </button>
                </div>

                {/* Trust Highlights */}
                <div className="pt-4 grid grid-cols-3 gap-4 max-w-lg mx-auto lg:mx-0 border-t border-[#D4AF37]/25">
                  <div>
                    <div className="font-serif text-lg sm:text-xl font-bold text-[#D4AF37]">
                      100% Fresh
                    </div>
                    <div className="text-xs text-[#FFF9EC]/75">Sealed Zipper Packs</div>
                  </div>
                  <div>
                    <div className="font-serif text-lg sm:text-xl font-bold text-[#D4AF37]">
                      COD Ready
                    </div>
                    <div className="text-xs text-[#FFF9EC]/75">Across Pakistan</div>
                  </div>
                  <div>
                    <div className="font-serif text-lg sm:text-xl font-bold text-[#D4AF37]">
                      WhatsApp
                    </div>
                    <div className="text-xs text-[#FFF9EC]/75">1-Tap Direct Ordering</div>
                  </div>
                </div>
              </div>

              {/* Right Luxury Photography & Packaging Badge */}
              <div className="lg:col-span-5 relative">
                <div className="relative rounded-3xl overflow-hidden border-2 border-[#D4AF37] shadow-2xl aspect-[4/4] sm:aspect-[4/3] lg:aspect-[4/4]">
                  <img
                    src={FOOD_IMAGES.heroFeast}
                    alt="Aroma Foods Traditional Pakistani Nimko, Chana, and Dry Fruits Assortment"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B3D2E]/85 via-transparent to-transparent" />

                  {/* Floating Packaging Quality Card */}
                  <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-[#064B35]/95 backdrop-blur-md border border-[#D4AF37]/70 p-4 text-[#FFF9EC] shadow-xl">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <div className="text-[10px] uppercase tracking-[0.2em] text-[#D4AF37] font-bold">
                          Signature Stand-Up Pouch
                        </div>
                        <div className="font-serif text-base font-bold text-white">
                          Emerald & Gold Fresh-Lock Pack
                        </div>
                        <div className="text-xs text-[#FFF9EC]/80 mt-0.5">
                          Transparent display window • Resealable freshness
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleSelectProduct('prod-special-nimko')}
                        className="shrink-0 px-3.5 py-2 rounded-xl bg-[#D4AF37] text-[#0B3D2E] text-xs font-bold hover:bg-[#F3E5AB] transition-colors"
                      >
                        View Pack
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 2. FEATURED CATEGORIES */}
        <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.22em] text-[#9A7B1C]">
                Curated Collections
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35] mt-1">
                Explore Our Categories
              </h2>
            </div>
            <button
              type="button"
              onClick={() => navigateTo('shop', { category: 'All' })}
              className="inline-flex items-center gap-2 text-sm font-bold text-[#064B35] hover:text-[#9A7B1C] transition-colors"
            >
              <span>View Full Catalog</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {categories.map((cat) => {
              const count = products.filter((p) => p.category === cat.name).length;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => navigateTo('shop', { category: cat.name })}
                  className="group text-left rounded-2xl bg-white p-5 sm:p-6 border border-[#D4AF37]/40 hover:border-[#064B35] shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#FFF9EC] text-[#9A7B1C] border border-[#D4AF37]/40">
                        {cat.badge || 'Aroma Selection'}
                      </span>
                      <span className="w-8 h-8 rounded-full bg-[#064B35]/5 group-hover:bg-[#064B35] text-[#064B35] group-hover:text-[#D4AF37] flex items-center justify-center transition-colors">
                        <ChevronRight className="w-4 h-4" />
                      </span>
                    </div>
                    <h3 className="font-serif text-lg sm:text-xl font-bold text-[#064B35] group-hover:text-[#0B3D2E]">
                      {cat.name}
                    </h3>
                    <p className="text-xs text-[#252525]/75 mt-1.5 line-clamp-2 leading-relaxed">
                      {cat.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#D4AF37]/20 flex items-center justify-between text-xs font-semibold text-[#064B35]">
                    <span>
                      {count} {count === 1 ? 'Product' : 'Products'}
                    </span>
                    <span className="group-hover:translate-x-1 transition-transform text-[#9A7B1C]">
                      Browse →
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* 3. BEST SELLING PRODUCTS */}
        <section className="py-16 sm:py-20 bg-white/70 border-y border-[#D4AF37]/30 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
              <div>
                <span className="text-xs font-bold uppercase tracking-[0.22em] text-[#9A7B1C]">
                  Most Loved Across Pakistan
                </span>
                <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35] mt-1">
                  Best Selling Products
                </h2>
                <p className="text-xs sm:text-sm text-[#252525]/70 mt-1">
                  Note: Product weights and PKR prices shown below are editable sample entries
                  configurable in the Admin Dashboard.
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigateTo('shop', { category: 'All' })}
                className="px-5 py-2.5 rounded-xl bg-[#064B35] text-[#FFF9EC] text-sm font-semibold hover:bg-[#0B3D2E] border border-[#D4AF37]/50 transition-colors self-start sm:self-auto"
              >
                Shop All Snacks
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {bestSellers.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelectProduct={handleSelectProduct}
                  onAddToCart={handleAddToCart}
                  onBuyNow={handleBuyNow}
                  onWhatsAppOrder={handleProductWhatsAppOrder}
                />
              ))}
            </div>
          </div>
        </section>

        {/* 4. WHY CHOOSE AROMA FOODS? */}
        <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-[0.22em] text-[#9A7B1C]">
              The Aroma Standard
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35] mt-1">
              Why Choose Aroma Foods?
            </h2>
            <p className="text-sm sm:text-base text-[#252525]/80 mt-2">
              Every pouch reflects our dedication to authentic taste, clean preparation, and
              dependable freshness.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
            {[
              {
                icon: Award,
                title: 'Premium Quality',
                desc: 'Carefully graded lentils, chickpeas, nuts, and dates selected for superior crunch and taste.'
              },
              {
                icon: Sparkles,
                title: 'Freshly Packed',
                desc: 'Sealed in moisture-barrier stand-up zipper pouches to preserve crispness from first bite to last.'
              },
              {
                icon: Heart,
                title: 'Traditional Taste',
                desc: 'Time-honored Pakistani spice profiles crafted for authentic tea-time and festive hospitality.'
              },
              {
                icon: Leaf,
                title: 'Quality Ingredients',
                desc: 'Wholesome pulses, groundnuts, and aromatic spices prepared with care and consistency.'
              },
              {
                icon: ShieldCheck,
                title: 'Hygienic Packaging',
                desc: 'Clean, food-safe resealable packaging with transparent windows so you see what you enjoy.'
              }
            ].map((item) => {
              const IconComp = item.icon;
              return (
                <div
                  key={item.title}
                  className="rounded-2xl bg-white p-6 border border-[#D4AF37]/40 hover:border-[#064B35] shadow-sm text-center flex flex-col items-center transition-all"
                >
                  <div className="w-12 h-12 rounded-2xl bg-[#064B35] text-[#D4AF37] flex items-center justify-center mb-4 shadow-md border border-[#D4AF37]/50">
                    <IconComp className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-[#064B35] mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#252525]/75 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </section>

        {/* 5. BRAND STORY & PACKAGING IDENTITY SECTION */}
        <section className="py-16 sm:py-20 bg-[#0B3D2E] text-[#FFF9EC] px-4 sm:px-6 lg:px-8 border-y border-[#D4AF37]/50">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-5">
              <span className="inline-block text-xs font-bold uppercase tracking-[0.24em] text-[#D4AF37]">
                Our Heritage & Craft
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white leading-tight">
                Rooted in Pakistani Hospitality, Sealed for Modern Homes
              </h2>
              <p className="text-sm sm:text-base text-[#FFF9EC]/85 leading-relaxed">
                In every Pakistani household, sharing a bowl of crisp Nimko, roasted Chana, or
                sweet Khajoor over evening chai is a cherished ritual. Aroma Foods was created to
                bring that unmistakable taste of tradition to your table with consistent hygiene,
                careful ingredient selection, and refined stand-up zipper packaging.
              </p>
              <div className="pt-2 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => navigateTo('about')}
                  className="px-6 py-3 rounded-xl bg-[#D4AF37] text-[#0B3D2E] font-bold text-sm hover:bg-[#F3E5AB] transition-colors inline-flex items-center gap-2"
                >
                  <span>Read Our Story</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => navigateTo('shop', { category: 'All' })}
                  className="px-6 py-3 rounded-xl border border-[#D4AF37]/60 text-[#FFF9EC] font-semibold text-sm hover:bg-white/10 transition-colors"
                >
                  Browse Collection
                </button>
              </div>
            </div>

            <div className="lg:col-span-6">
              <PackagingMockupCard product={products[0]} />
            </div>
          </div>
        </section>

        {/* 6. PROMOTIONAL BANNER */}
        <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="rounded-3xl bg-gradient-to-r from-[#FFF9EC] via-[#FBF1D6] to-[#FFF9EC] border-2 border-[#D4AF37] p-6 sm:p-10 shadow-md flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center md:text-left">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#064B35] text-[#F3E5AB] text-xs font-bold">
                <Truck className="w-3.5 h-3.5 text-[#D4AF37]" /> Nationwide Delivery Offer
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#064B35]">
                Enjoy Free Delivery on Orders Above {formatPKR(storeConfig.freeDeliveryThreshold)}
              </h3>
              <p className="text-sm text-[#252525]/80">
                Stock up on your favorite tea-time savories with convenient Cash on Delivery across
                Pakistan.
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigateTo('shop', { category: 'All' })}
              className="shrink-0 px-7 py-4 rounded-xl bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] font-bold text-sm border border-[#D4AF37] shadow-md transition-all"
            >
              Build Your Snack Box →
            </button>
          </div>
        </section>

        {/* 7. CUSTOMER TESTIMONIALS (CLEARLY MARKED SAMPLE CONTENT) */}
        <section className="py-14 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-[0.22em] text-[#9A7B1C]">
              Customer Feedback
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35] mt-1">
              What Snack Lovers Say
            </h2>
            <p className="mt-2 inline-block px-3 py-1 rounded-full bg-amber-100/80 text-amber-900 text-xs font-medium border border-amber-300">
              Sample Testimonials — Replace with verified customer reviews once orders are live
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {SAMPLE_TESTIMONIALS.map((rev) => (
              <div
                key={rev.id}
                className="rounded-2xl bg-white p-6 border border-[#D4AF37]/40 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-1 text-[#D4AF37]">
                      {[...Array(5)].map((_, idx) => (
                        <Star key={idx} className="w-4 h-4 fill-[#D4AF37]" />
                      ))}
                    </div>
                    <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-[#FFF9EC] text-[#9A7B1C] border border-[#D4AF37]/30">
                      Sample Review
                    </span>
                  </div>
                  <p className="text-sm text-[#252525]/85 italic leading-relaxed mb-4">
                    “{rev.quote}”
                  </p>
                </div>
                <div className="pt-3 border-t border-[#D4AF37]/20 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-sm text-[#064B35]">{rev.name}</div>
                    <div className="text-xs text-[#252525]/60">{rev.city}, Pakistan</div>
                  </div>
                  <span className="text-xs font-medium text-[#9A7B1C]">{rev.product}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 8. WHATSAPP ORDERING SECTION */}
        <section className="py-14 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="rounded-3xl bg-gradient-to-br from-[#064B35] to-[#0B3D2E] text-[#FFF9EC] p-8 sm:p-12 border-2 border-[#D4AF37] shadow-xl relative overflow-hidden">
            <div className="grid lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-8 space-y-4">
                <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#25D366]/20 border border-[#25D366]/50 text-[#F3E5AB] text-xs font-bold">
                  <MessageCircle className="w-4 h-4 text-[#25D366]" />
                  <span>Direct WhatsApp Concierge</span>
                </div>
                <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white">
                  Prefer Ordering Directly on WhatsApp?
                </h2>
                <p className="text-sm sm:text-base text-[#FFF9EC]/85 max-w-2xl leading-relaxed">
                  Send us your selected snacks, pack weights (250g, 500g, or 1kg), and delivery
                  city in one tap. Our team confirms availability and Cash on Delivery dispatch
                  promptly.
                </p>
                <div className="text-xs text-[#F3E5AB]/80 font-mono">
                  Configured WhatsApp Line: +{storeConfig.WHATSAPP_NUMBER}
                </div>
              </div>

              <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3">
                <button
                  type="button"
                  onClick={() =>
                    openWhatsAppWithMessage(
                      `Assalam-o-Alaikum Aroma Foods!\n\nI would like to place an order.\n\nProduct: [Product Name]\nWeight: [Selected Weight]\nQuantity: [Quantity]\n\nCustomer Name: [Name]\nDelivery Address: [Address]\nCity: [City]\n\nPlease confirm my order.`
                    )
                  }
                  className="w-full py-4 px-6 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#062E22] font-extrabold text-sm sm:text-base shadow-lg flex items-center justify-center gap-2 transition-all"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Order via WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={() => navigateTo('contact')}
                  className="w-full py-3.5 px-6 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm border border-[#D4AF37]/50 transition-colors"
                >
                  Ask a Question
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  };

  // ==========================================================================
  // RENDER: SHOP PAGE
  // ==========================================================================
  const renderShopPage = () => {
    const filteredProducts = products
      .filter((p) => {
        if (shopCategoryFilter !== 'All' && p.category !== shopCategoryFilter) return false;
        if (shopInStockOnly && !p.inStock) return false;
        if (shopSearchQuery.trim()) {
          const q = shopSearchQuery.toLowerCase();
          const matchName = p.name.toLowerCase().includes(q);
          const matchCat = p.category.toLowerCase().includes(q);
          const matchDesc = p.description.toLowerCase().includes(q);
          return matchName || matchCat || matchDesc;
        }
        return true;
      })
      .sort((a, b) => {
        const priceA = a.weights[0]?.price || 0;
        const priceB = b.weights[0]?.price || 0;
        if (shopSortBy === 'price-asc') return priceA - priceB;
        if (shopSortBy === 'price-desc') return priceB - priceA;
        if (shopSortBy === 'name-asc') return a.name.localeCompare(b.name);
        // featured: best sellers first
        return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
      });

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        {/* Page Header */}
        <div className="mb-8 pb-6 border-b border-[#D4AF37]/35 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <nav className="text-xs text-[#9A7B1C] font-semibold mb-2 flex items-center gap-1.5">
              <button type="button" onClick={() => navigateTo('home')} className="hover:underline">
                Home
              </button>
              <span>/</span>
              <span>Shop Collection</span>
            </nav>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35]">
              {shopCategoryFilter === 'All'
                ? 'All Traditional Snacks & Dry Fruits'
                : `${shopCategoryFilter} Collection`}
            </h1>
            <p className="text-xs sm:text-sm text-[#252525]/75 mt-1">
              Select your preferred pack size (250g, 500g, 1kg) and order online or via WhatsApp.
              <span className="ml-1 text-[#9A7B1C] font-medium">
                [Sample pricing & details editable in Admin]
              </span>
            </p>
          </div>

          <div className="text-xs font-semibold text-[#064B35] bg-white px-4 py-2 rounded-xl border border-[#D4AF37]/40 self-start md:self-auto">
            Showing {filteredProducts.length} of {products.length} products
          </div>
        </div>

        {/* Search, Sort & Stock Controls */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#D4AF37]/40 shadow-sm mb-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
            {/* Search Input */}
            <div className="md:col-span-6 relative">
              <Search className="w-4 h-4 text-[#064B35]/60 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={shopSearchQuery}
                onChange={(e) => setShopSearchQuery(e.target.value)}
                placeholder="Search Nimko, Chana, Daal, Peanuts, Khajoor..."
                className="w-full pl-10 pr-9 py-2.5 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
              />
              {shopSearchQuery && (
                <button
                  type="button"
                  onClick={() => setShopSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Price Sorting */}
            <div className="md:col-span-3">
              <select
                value={shopSortBy}
                onChange={(e) => setShopSortBy(e.target.value)}
                aria-label="Sort products"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm font-medium text-[#252525]"
              >
                <option value="featured">Sort: Featured & Best Sellers</option>
                <option value="price-asc">Price: Low to High (PKR)</option>
                <option value="price-desc">Price: High to Low (PKR)</option>
                <option value="name-asc">Name: A to Z</option>
              </select>
            </div>

            {/* In-Stock Toggle */}
            <div className="md:col-span-3 flex items-center justify-between md:justify-end gap-3">
              <label className="inline-flex items-center gap-2 cursor-pointer text-sm font-medium text-[#252525] select-none">
                <input
                  type="checkbox"
                  checked={shopInStockOnly}
                  onChange={(e) => setShopInStockOnly(e.target.checked)}
                  className="w-4 h-4 rounded accent-[#064B35]"
                />
                <span>In Stock Only</span>
              </label>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setShopCategoryFilter('All')}
              className={`shrink-0 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                shopCategoryFilter === 'All'
                  ? 'bg-[#064B35] text-[#FFF9EC] border-[#064B35] shadow-sm'
                  : 'bg-[#FFF9EC] text-[#252525] border-[#D4AF37]/40 hover:border-[#064B35]'
              }`}
            >
              All ({products.length})
            </button>

            {categories.map((cat) => {
              const active = shopCategoryFilter === cat.name;
              const count = products.filter((p) => p.category === cat.name).length;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setShopCategoryFilter(cat.name)}
                  className={`shrink-0 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                    active
                      ? 'bg-[#064B35] text-[#FFF9EC] border-[#064B35] shadow-sm'
                      : 'bg-[#FFF9EC] text-[#252525] border-[#D4AF37]/40 hover:border-[#064B35]'
                  }`}
                >
                  {cat.name} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="rounded-3xl bg-white border border-[#D4AF37]/40 p-12 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-[#FFF9EC] text-[#064B35] border border-[#D4AF37]/50 flex items-center justify-center mx-auto">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-[#064B35]">
              No matching products found
            </h3>
            <p className="text-sm text-[#252525]/75 max-w-md mx-auto">
              Try clearing your search term or switching back to all categories to view our full
              selection.
            </p>
            <button
              type="button"
              onClick={() => {
                setShopCategoryFilter('All');
                setShopSearchQuery('');
                setShopInStockOnly(false);
              }}
              className="px-6 py-3 rounded-xl bg-[#064B35] text-[#FFF9EC] text-sm font-semibold"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onSelectProduct={handleSelectProduct}
                onAddToCart={handleAddToCart}
                onBuyNow={handleBuyNow}
                onWhatsAppOrder={handleProductWhatsAppOrder}
              />
            ))}
          </div>
        )}
      </div>
    );
  };

  // ==========================================================================
  // RENDER: PRODUCT DETAILS PAGE
  // ==========================================================================
  const ProductDetailsView = () => {
    const product = products.find((p) => p.id === selectedProductId) || products[0];
    const [weightIdx, setWeightIdx] = useState(0);
    const [qty, setQty] = useState(1);
    const [activeInfoTab, setActiveInfoTab] = useState('packaging');

    useEffect(() => {
      setWeightIdx(0);
      setQty(1);
    }, [product.id]);

    const currentWeight = product.weights[weightIdx] || product.weights[0];
    const relatedProducts = products
      .filter((p) => p.id !== product.id && (p.category === product.category || p.isBestSeller))
      .slice(0, 3);

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Breadcrumb */}
        <nav className="text-xs font-semibold text-[#9A7B1C] mb-6 flex flex-wrap items-center gap-2">
          <button type="button" onClick={() => navigateTo('home')} className="hover:underline">
            Home
          </button>
          <span>/</span>
          <button
            type="button"
            onClick={() => navigateTo('shop', { category: product.category })}
            className="hover:underline"
          >
            {product.category}
          </button>
          <span>/</span>
          <span className="text-[#064B35]">{product.name}</span>
        </nav>

        {/* Main Two-Column Product Section */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left Image + Packaging Preview */}
          <div className="lg:col-span-6 space-y-6">
            <div className="relative rounded-3xl overflow-hidden bg-white border-2 border-[#D4AF37]/50 shadow-lg aspect-[4/3]">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#064B35] text-[#F3E5AB] border border-[#D4AF37]/60">
                  {product.category}
                </span>
                {product.isBestSeller && (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#D4AF37] text-[#0B3D2E]">
                    Best Seller
                  </span>
                )}
              </div>
            </div>

            <PackagingMockupCard product={product} />
          </div>

          {/* Right Purchase & Specification Panel */}
          <div className="lg:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/45 shadow-md space-y-6">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#9A7B1C]">
                  {product.shortTag || 'Aroma Foods Selection'}
                </span>
                {product.inStock ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-[#064B35] border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5" /> In Stock & Ready to Dispatch
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-50 text-red-700 border border-red-200">
                    <AlertCircle className="w-3.5 h-3.5" /> Currently Out of Stock
                  </span>
                )}
              </div>

              <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35]">
                {product.name}
              </h1>
            </div>

            {/* Dynamic Price Display */}
            <div className="p-4 rounded-2xl bg-[#FFF9EC] border border-[#D4AF37]/40 flex flex-wrap items-baseline justify-between gap-2">
              <div>
                <span className="text-2xl sm:text-3xl font-extrabold text-[#064B35]">
                  {formatPKR(currentWeight.price * qty)}
                </span>
                <span className="text-xs text-[#252525]/70 ml-2">
                  ({formatPKR(currentWeight.price)} per {currentWeight.label} pack)
                </span>
              </div>
              <span className="text-[11px] font-semibold text-[#9A7B1C]">
                [Sample Price — Editable in Admin]
              </span>
            </div>

            <p className="text-sm sm:text-base text-[#252525]/85 leading-relaxed">
              {product.description}
            </p>

            {/* Weight Selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-2.5">
                1. Choose Pouch Weight
              </label>
              <div className="grid grid-cols-3 gap-3">
                {product.weights.map((w, idx) => {
                  const selected = idx === weightIdx;
                  return (
                    <button
                      key={w.label}
                      type="button"
                      onClick={() => setWeightIdx(idx)}
                      className={`p-3 rounded-xl border-2 text-left transition-all ${
                        selected
                          ? 'bg-[#064B35] text-[#FFF9EC] border-[#064B35] shadow-md'
                          : 'bg-[#FFF9EC]/60 text-[#252525] border-[#D4AF37]/40 hover:border-[#064B35]'
                      }`}
                    >
                      <div className="font-bold text-sm">{w.label}</div>
                      <div
                        className={`text-xs mt-0.5 font-semibold ${
                          selected ? 'text-[#D4AF37]' : 'text-[#064B35]'
                        }`}
                      >
                        {formatPKR(w.price)}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity Stepper */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-2.5">
                2. Select Quantity
              </label>
              <div className="inline-flex items-center rounded-xl border border-[#D4AF37]/60 bg-[#FFF9EC] p-1">
                <button
                  type="button"
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="w-10 h-10 rounded-lg flex items-center justify-center text-[#064B35] hover:bg-white transition-colors"
                  aria-label="Decrease quantity"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-bold text-base text-[#064B35]">{qty}</span>
                <button
                  type="button"
                  onClick={() => setQty((q) => q + 1)}
                  className="w-10 h-10 rounded-lg flex items-center justify-center text-[#064B35] hover:bg-white transition-colors"
                  aria-label="Increase quantity"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Primary Purchase Actions */}
            <div className="space-y-3 pt-2">
              <div className="grid sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={!product.inStock}
                  onClick={() => handleAddToCart(product, currentWeight, qty)}
                  className={`py-4 px-5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 border-2 transition-all ${
                    product.inStock
                      ? 'bg-[#FFF9EC] text-[#064B35] border-[#064B35] hover:bg-[#064B35] hover:text-[#FFF9EC]'
                      : 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                  }`}
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>Add to Cart</span>
                </button>

                <button
                  type="button"
                  disabled={!product.inStock}
                  onClick={() => handleBuyNow(product, currentWeight, qty)}
                  className={`py-4 px-5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all ${
                    product.inStock
                      ? 'bg-[#064B35] text-[#FFF9EC] hover:bg-[#0B3D2E] border border-[#D4AF37]'
                      : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  <span>Buy Now (COD)</span>
                  <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                </button>
              </div>

              <button
                type="button"
                onClick={() => handleProductWhatsAppOrder(product, currentWeight, qty)}
                className="w-full py-3.5 px-5 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366] text-[#0B3D2E] hover:text-[#062E22] border border-[#25D366]/50 font-bold text-sm flex items-center justify-center gap-2 transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Order This Product on WhatsApp</span>
              </button>
            </div>

            {/* Product Information Tabs */}
            <div className="pt-4 border-t border-[#D4AF37]/30">
              <div className="flex gap-2 border-b border-[#D4AF37]/25 pb-2 mb-3 overflow-x-auto">
                {[
                  { id: 'packaging', label: 'Packaging & Storage' },
                  { id: 'ingredients', label: 'Ingredients (Editable)' },
                  { id: 'delivery', label: 'Delivery & COD' }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveInfoTab(tab.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 transition-colors ${
                      activeInfoTab === tab.id
                        ? 'bg-[#064B35] text-[#FFF9EC]'
                        : 'text-[#252525]/70 hover:bg-[#FFF9EC]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {activeInfoTab === 'packaging' && (
                <p className="text-xs sm:text-sm text-[#252525]/80 leading-relaxed">
                  Packed in Aroma Foods’ signature deep emerald green stand-up zipper pouch with
                  metallic gold detailing and a clear product window. Reseal tightly after opening
                  and store in a cool, dry place away from direct sunlight to maintain crispness.
                </p>
              )}
              {activeInfoTab === 'ingredients' && (
                <p className="text-xs sm:text-sm text-[#252525]/80 leading-relaxed bg-amber-50/70 p-3 rounded-xl border border-amber-200">
                  {product.ingredientsPlaceholder ||
                    '[Placeholder: Enter verified ingredients and allergen declarations for this product in Admin.]'}
                </p>
              )}
              {activeInfoTab === 'delivery' && (
                <p className="text-xs sm:text-sm text-[#252525]/80 leading-relaxed">
                  Cash on Delivery (COD) available across Pakistan. Flat delivery charge of{' '}
                  {formatPKR(storeConfig.deliveryFee)}, or FREE delivery on orders above{' '}
                  {formatPKR(storeConfig.freeDeliveryThreshold)}.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-16 pt-12 border-t border-[#D4AF37]/35">
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#064B35] mb-6">
              You May Also Enjoy
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedProducts.map((rel) => (
                <ProductCard
                  key={rel.id}
                  product={rel}
                  onSelectProduct={handleSelectProduct}
                  onAddToCart={handleAddToCart}
                  onBuyNow={handleBuyNow}
                  onWhatsAppOrder={handleProductWhatsAppOrder}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  // ==========================================================================
  // RENDER: ABOUT US PAGE
  // ==========================================================================
  const renderAboutPage = () => (
    <div>
      {/* Hero Banner */}
      <section className="bg-gradient-to-br from-[#064B35] to-[#0B3D2E] text-[#FFF9EC] py-16 sm:py-20 px-4 sm:px-6 lg:px-8 border-b-2 border-[#D4AF37]">
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <span className="inline-block text-xs font-bold uppercase tracking-[0.25em] text-[#D4AF37]">
            About Aroma Foods
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl font-bold text-white">
            Our Story, Our Tradition
          </h1>
          <p className="text-base sm:text-lg text-[#FFF9EC]/90 leading-relaxed max-w-2xl mx-auto">
            Dedicated to bringing the authentic taste of traditional Pakistani snacks to families
            with uncompromised quality, freshness, and care.
          </p>
        </div>
      </section>

      {/* Main Narrative */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20 space-y-16">
        <div className="grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6">
            <div className="rounded-3xl overflow-hidden border-2 border-[#D4AF37] shadow-xl aspect-[4/3]">
              <img
                src={FOOD_IMAGES.traditionalPlatter}
                alt="Traditional Pakistani Snacks Assortment by Aroma Foods"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#9A7B1C]">
              Taste of Tradition
            </span>
            <h2 className="font-serif text-3xl font-bold text-[#064B35]">
              Authentic Flavors Crafted for Modern Pakistani Homes
            </h2>
            <p className="text-sm sm:text-base text-[#252525]/85 leading-relaxed">
              Traditional snacks hold a special place in Pakistani culture—from warm afternoon tea
              with family to welcoming guests with generosity. At <strong>Aroma Foods</strong>, we
              focus on preserving those timeless recipes and textures while elevating how snacks are
              packed, stored, and delivered.
            </p>
            <p className="text-sm sm:text-base text-[#252525]/85 leading-relaxed">
              Every batch of our Nimko, Besan Chana, Roasted Chana, Daal Moong, Peanuts, and
              Khajoor is thoughtfully selected and sealed inside our signature deep emerald green
              and gold stand-up zipper pouches—so every opening feels crisp, clean, and fresh.
            </p>
            <div className="p-4 rounded-2xl bg-white border border-[#D4AF37]/40 text-xs text-[#252525]/75">
              <strong className="text-[#064B35]">Business Profile Note:</strong> Additional verified
              company milestones, certifications, or city origin details can be added directly by
              the business owner.
            </div>
          </div>
        </div>

        {/* Mission, Vision, Quality Pillars */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="rounded-2xl bg-white p-7 border border-[#D4AF37]/45 shadow-sm space-y-3">
            <div className="w-11 h-11 rounded-xl bg-[#064B35] text-[#D4AF37] flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-xl font-bold text-[#064B35]">Our Mission</h3>
            <p className="text-sm text-[#252525]/80 leading-relaxed">
              To deliver wholesome, freshly packed traditional Pakistani snacks and dry fruits that
              families can serve with pride and trust every single day.
            </p>
          </div>

          <div className="rounded-2xl bg-white p-7 border border-[#D4AF37]/45 shadow-sm space-y-3">
            <div className="w-11 h-11 rounded-xl bg-[#064B35] text-[#D4AF37] flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-xl font-bold text-[#064B35]">Our Vision</h3>
            <p className="text-sm text-[#252525]/80 leading-relaxed">
              To stand as a benchmark Pakistani food brand recognized for authentic flavor,
              hygienic resealable packaging, and dependable customer care.
            </p>
          </div>

          <div className="rounded-2xl bg-white p-7 border border-[#D4AF37]/45 shadow-sm space-y-3">
            <div className="w-11 h-11 rounded-xl bg-[#064B35] text-[#D4AF37] flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-xl font-bold text-[#064B35]">Commitment to Quality</h3>
            <p className="text-sm text-[#252525]/80 leading-relaxed">
              From careful ingredient grading to airtight zipper-lock pouches with clear product
              windows, hygiene and freshness guide every step of our process.
            </p>
          </div>
        </div>

        {/* Packaging Showcase */}
        <PackagingMockupCard product={products[0]} />
      </section>
    </div>
  );

  // ==========================================================================
  // RENDER: CONTACT PAGE
  // ==========================================================================
  const ContactPageView = () => {
    const [form, setForm] = useState({
      name: '',
      phone: '',
      email: '',
      subject: 'Product Enquiry',
      message: ''
    });
    const [errors, setErrors] = useState({});
    const [submitted, setSubmitted] = useState(false);

    const validate = () => {
      const next = {};
      if (!form.name.trim()) next.name = 'Please enter your full name.';
      if (!form.phone.trim()) next.phone = 'Please enter your phone or WhatsApp number.';
      if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
        next.email = 'Please enter a valid email address.';
      }
      if (!form.message.trim() || form.message.trim().length < 10) {
        next.message = 'Please write a brief message (at least 10 characters).';
      }
      setErrors(next);
      return Object.keys(next).length === 0;
    };

    const handleSubmit = (e) => {
      e.preventDefault();
      if (!validate()) return;

      const newInquiry = {
        id: 'INQ-' + Date.now().toString().slice(-6),
        ...form,
        createdAt: new Date().toISOString()
      };
      setInquiries((prev) => [newInquiry, ...prev]);
      setSubmitted(true);
      showToast('Message Sent', 'Thank you for contacting Aroma Foods.');
    };

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-[0.22em] text-[#9A7B1C]">
            We Are Here to Help
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35] mt-1">
            Contact Aroma Foods
          </h1>
          <p className="text-sm sm:text-base text-[#252525]/80 mt-2">
            Have a question about bulk family packs, gift assortments, or delivery to your city?
            Reach out via WhatsApp or send us a message below.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-8 items-start">
          {/* Left Business Details & WhatsApp Card */}
          <div className="lg:col-span-5 space-y-6">
            <div className="rounded-3xl bg-[#064B35] text-[#FFF9EC] p-7 border-2 border-[#D4AF37] shadow-xl space-y-5">
              <h2 className="font-serif text-2xl font-bold text-white">Direct WhatsApp Support</h2>
              <p className="text-sm text-[#FFF9EC]/85 leading-relaxed">
                For fastest assistance and instant order confirmation, message our team directly on
                WhatsApp.
              </p>
              <button
                type="button"
                onClick={() =>
                  openWhatsAppWithMessage(
                    'Assalam-o-Alaikum Aroma Foods! I have a question regarding your products.'
                  )
                }
                className="w-full py-3.5 px-5 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#062E22] font-extrabold text-sm flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Chat on WhatsApp (+{storeConfig.WHATSAPP_NUMBER})</span>
              </button>
            </div>

            <div className="rounded-3xl bg-white p-7 border border-[#D4AF37]/45 shadow-sm space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-xl font-bold text-[#064B35]">Business Details</h3>
                <span className="text-[10px] font-bold uppercase px-2.5 py-0.5 rounded bg-amber-100 text-amber-900">
                  Editable Placeholders
                </span>
              </div>

              <div className="space-y-4 text-sm">
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-[#9A7B1C] shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-[#064B35]">Phone / WhatsApp</div>
                    <div className="text-[#252525]/80">{storeConfig.phonePlaceholder}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-[#9A7B1C] shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-[#064B35]">Email Address</div>
                    <div className="text-[#252525]/80">{storeConfig.emailPlaceholder}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#9A7B1C] shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-[#064B35]">Business Address</div>
                    <div className="text-[#252525]/80">{storeConfig.addressPlaceholder}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-[#9A7B1C] shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-[#064B35]">Customer Support Hours</div>
                    <div className="text-[#252525]/80">{storeConfig.operatingHours}</div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#D4AF37]/25">
                <div className="text-xs font-bold uppercase tracking-wider text-[#9A7B1C] mb-2">
                  Social Channels (Placeholders)
                </div>
                <div className="flex gap-2">
                  {Object.entries(storeConfig.socialLinks).map(([platform, url]) => (
                    <a
                      key={platform}
                      href={url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2 rounded-xl bg-[#FFF9EC] text-[#064B35] hover:bg-[#064B35] hover:text-[#FFF9EC] border border-[#D4AF37]/40 text-xs font-semibold capitalize transition-colors"
                    >
                      {platform}
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right Contact Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/45 shadow-sm">
            {submitted ? (
              <div className="py-10 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#064B35] flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#064B35]">
                  Thank You! Your Message Has Been Received
                </h2>
                <p className="text-sm text-[#252525]/80 max-w-md mx-auto">
                  We have recorded your inquiry for the Aroma Foods team. For immediate response,
                  you can also reach us on WhatsApp.
                </p>
                <div className="pt-3 flex flex-wrap justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setSubmitted(false);
                      setForm({
                        name: '',
                        phone: '',
                        email: '',
                        subject: 'Product Enquiry',
                        message: ''
                      });
                    }}
                    className="px-6 py-3 rounded-xl bg-[#064B35] text-[#FFF9EC] text-sm font-semibold"
                  >
                    Send Another Message
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('shop', { category: 'All' })}
                    className="px-6 py-3 rounded-xl bg-[#FFF9EC] text-[#064B35] border border-[#064B35] text-sm font-semibold"
                  >
                    Explore Products
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <h2 className="font-serif text-2xl font-bold text-[#064B35]">Send Us a Message</h2>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="e.g. Muhammad Bilal"
                      className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
                    />
                    {errors.name && (
                      <p className="text-xs text-red-600 mt-1 font-medium">{errors.name}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                      Phone / WhatsApp Number *
                    </label>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder="03XX-XXXXXXX"
                      className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
                    />
                    {errors.phone && (
                      <p className="text-xs text-red-600 mt-1 font-medium">{errors.phone}</p>
                    )}
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="you@example.com"
                      className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
                    />
                    {errors.email && (
                      <p className="text-xs text-red-600 mt-1 font-medium">{errors.email}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                      Subject
                    </label>
                    <select
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
                    >
                      <option value="Product Enquiry">Product Enquiry</option>
                      <option value="Bulk / Event Order">Bulk / Event Order</option>
                      <option value="Delivery & Tracking">Delivery & Tracking</option>
                      <option value="Feedback">Feedback</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                    Message *
                  </label>
                  <textarea
                    rows={4}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Write your inquiry, preferred snack varieties, or delivery city..."
                    className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
                  />
                  {errors.message && (
                    <p className="text-xs text-red-600 mt-1 font-medium">{errors.message}</p>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full py-4 px-6 rounded-xl bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] font-bold text-sm border border-[#D4AF37] shadow-md transition-all"
                >
                  Submit Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    );
  };

  // ==========================================================================
  // RENDER: DEDICATED CART PAGE
  // ==========================================================================
  const renderCartPage = () => (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8 pb-5 border-b border-[#D4AF37]/35">
        <div>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35]">
            Your Shopping Cart
          </h1>
          <p className="text-sm text-[#252525]/75 mt-1">
            Review your selected Aroma Foods packs before proceeding to Cash on Delivery checkout.
          </p>
        </div>
        <button
          type="button"
          onClick={() => navigateTo('shop', { category: 'All' })}
          className="px-4 py-2.5 rounded-xl bg-white text-[#064B35] border border-[#D4AF37]/50 text-sm font-semibold hover:bg-[#FFF9EC]"
        >
          ← Continue Shopping
        </button>
      </div>

      {cart.length === 0 ? (
        <div className="rounded-3xl bg-white border border-[#D4AF37]/45 p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-[#FFF9EC] text-[#064B35] border border-[#D4AF37]/50 flex items-center justify-center mx-auto">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="font-serif text-2xl font-bold text-[#064B35]">
            Your Aroma Foods Cart is Empty
          </h2>
          <p className="text-sm text-[#252525]/75 max-w-md mx-auto">
            Explore our crisp Nimko, roasted Chana, golden Daal Moong, and hand-selected Khajoor
            pouches.
          </p>
          <button
            type="button"
            onClick={() => navigateTo('shop', { category: 'All' })}
            className="px-7 py-3.5 rounded-xl bg-[#064B35] text-[#FFF9EC] font-bold text-sm border border-[#D4AF37]"
          >
            Browse Traditional Snacks
          </button>
        </div>
      ) : (
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          {/* Cart Items List */}
          <div className="lg:col-span-8 space-y-4">
            {cart.map((item) => (
              <div
                key={item.key}
                className="rounded-2xl bg-white p-4 sm:p-5 border border-[#D4AF37]/40 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-20 rounded-xl object-cover border border-[#D4AF37]/30 shrink-0"
                  />
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#9A7B1C]">
                      {item.category}
                    </span>
                    <h3 className="font-serif text-lg font-bold text-[#064B35]">{item.name}</h3>
                    <div className="text-xs text-[#252525]/75 mt-0.5">
                      Pack Weight: <strong className="text-[#064B35]">{item.weight}</strong> • Unit
                      Price: {formatPKR(item.price)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4 pt-3 sm:pt-0 border-t sm:border-t-0 border-[#D4AF37]/20">
                  {/* Qty Stepper */}
                  <div className="inline-flex items-center rounded-xl border border-[#D4AF37]/50 bg-[#FFF9EC] p-1">
                    <button
                      type="button"
                      onClick={() => updateCartQuantity(item.key, -1)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-[#064B35] hover:bg-white"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-9 text-center text-sm font-bold text-[#064B35]">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => updateCartQuantity(item.key, 1)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-[#064B35] hover:bg-white"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Line Total */}
                  <div className="text-right min-w-[95px]">
                    <div className="font-bold text-base text-[#064B35]">
                      {formatPKR(item.price * item.quantity)}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeFromCart(item.key)}
                    className="p-2 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
                    aria-label="Remove item"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary Box */}
          <div className="lg:col-span-4 rounded-3xl bg-white p-6 border-2 border-[#D4AF37]/60 shadow-md space-y-5">
            <h2 className="font-serif text-2xl font-bold text-[#064B35]">Order Summary</h2>

            <div className="space-y-2.5 text-sm border-y border-[#D4AF37]/25 py-4">
              <div className="flex justify-between text-[#252525]/80">
                <span>Subtotal ({cartItemCount} packs)</span>
                <span className="font-semibold text-[#252525]">{formatPKR(cartSubtotal)}</span>
              </div>
              <div className="flex justify-between text-[#252525]/80">
                <span>Standard Delivery</span>
                <span className="font-semibold text-[#064B35]">
                  {deliveryCharge === 0 ? 'FREE' : formatPKR(deliveryCharge)}
                </span>
              </div>
              {deliveryCharge > 0 && (
                <p className="text-xs text-[#9A7B1C]">
                  Add {formatPKR(storeConfig.freeDeliveryThreshold - cartSubtotal)} more to unlock
                  FREE nationwide delivery!
                </p>
              )}
            </div>

            <div className="flex justify-between items-baseline">
              <span className="font-bold text-base text-[#064B35]">Total Payable</span>
              <span className="font-extrabold text-2xl text-[#064B35]">
                {formatPKR(cartGrandTotal)}
              </span>
            </div>

            <div className="space-y-2.5 pt-2">
              <button
                type="button"
                onClick={() => navigateTo('checkout')}
                className="w-full py-4 px-5 rounded-xl bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] font-bold text-sm border border-[#D4AF37] shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
              </button>

              <button
                type="button"
                onClick={handleCartWhatsAppOrder}
                className="w-full py-3.5 px-5 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366] text-[#0B3D2E] hover:text-[#062E22] border border-[#25D366]/50 font-bold text-sm flex items-center justify-center gap-2 transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Order Cart via WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // ==========================================================================
  // RENDER: CHECKOUT PAGE & ORDER CONFIRMATION
  // ==========================================================================
  const CheckoutPageView = () => {
    const [customerName, setCustomerName] = useState('');
    const [phone, setPhone] = useState('');
    const [sameAsPhone, setSameAsPhone] = useState(true);
    const [whatsapp, setWhatsapp] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('Lahore');
    const [notes, setNotes] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');
    const [errors, setErrors] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [orderSuccessRecord, setOrderSuccessRecord] = useState(null);

    const buildConfirmedOrderWhatsAppMessage = (orderObj) => {
      const itemsText = orderObj.items
        .map(
          (i) =>
            `• ${i.name} (${i.weight}) × ${i.quantity} — ${formatPKR(i.price * i.quantity)}`
        )
        .join('\n');

      return `Assalam-o-Alaikum Aroma Foods!

I have placed an order on your website.

Order Reference: ${orderObj.reference}
${itemsText}

Total Price: ${formatPKR(orderObj.total)} (${orderObj.paymentMethod})

Customer Name: ${orderObj.customerName}
Phone: ${orderObj.phone}
Delivery Address: ${orderObj.address}
City: ${orderObj.city}${orderObj.notes ? `\nOrder Notes: ${orderObj.notes}` : ''}

Please confirm my order.`;
    };

    const validateCheckout = () => {
      const next = {};
      if (!customerName.trim() || customerName.trim().length < 2) {
        next.customerName = 'Please enter your full name.';
      }
      const cleanPhone = phone.replace(/[^0-9+]/g, '');
      if (!cleanPhone || cleanPhone.length < 10) {
        next.phone = 'Please enter a valid Pakistani mobile number (e.g., 0300-1234567).';
      }
      const effectiveWa = sameAsPhone ? phone : whatsapp;
      if (!effectiveWa.trim() || effectiveWa.replace(/[^0-9+]/g, '').length < 10) {
        next.whatsapp = 'Please enter a valid WhatsApp number for order updates.';
      }
      if (!address.trim() || address.trim().length < 8) {
        next.address = 'Please enter your complete street/house delivery address.';
      }
      if (!city.trim()) {
        next.city = 'Please select or enter your city.';
      }
      setErrors(next);
      return Object.keys(next).length === 0;
    };

    const handlePlaceOrder = (e) => {
      e.preventDefault();
      if (cart.length === 0) return;
      if (!validateCheckout()) {
        showToast('Check Required Fields', 'Please complete all highlighted delivery fields.');
        return;
      }

      setIsSubmitting(true);
      try {
        const year = new Date().getFullYear();
        const randomCode = Math.floor(1000 + Math.random() * 9000);
        const reference = `AF-${year}-${randomCode}`;

        const newOrder = {
          id: 'ord-' + Date.now(),
          reference,
          customerName: customerName.trim(),
          phone: phone.trim(),
          whatsapp: (sameAsPhone ? phone : whatsapp).trim(),
          address: address.trim(),
          city: city.trim(),
          notes: notes.trim(),
          paymentMethod,
          items: [...cart],
          subtotal: cartSubtotal,
          deliveryFee: deliveryCharge,
          total: cartGrandTotal,
          status: 'Pending',
          createdAt: new Date().toISOString()
        };

        // Persist order to backend/localStorage first before claiming confirmation
        const updatedOrders = [newOrder, ...orders];
        localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(updatedOrders));
        setOrders(updatedOrders);
        setLastPlacedOrder(newOrder);
        setOrderSuccessRecord(newOrder);
        setCart([]);
        showToast('Order Saved!', `Reference ${reference} created successfully.`);

        // Open WhatsApp with structured order confirmation message
        const waMsg = buildConfirmedOrderWhatsAppMessage(newOrder);
        openWhatsAppWithMessage(waMsg);
      } catch (err) {
        console.error('Order save error:', err);
        showToast('Order Error', 'Could not save order locally. Please try again.');
      } finally {
        setIsSubmitting(false);
      }
    };

    // Order Confirmation Screen after verified persistence
    if (orderSuccessRecord) {
      return (
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
          <div className="rounded-3xl bg-white border-2 border-[#D4AF37] p-6 sm:p-10 shadow-xl space-y-6">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#064B35] flex items-center justify-center mx-auto border border-emerald-300">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <span className="inline-block px-3 py-1 rounded-full bg-[#FFF9EC] text-[#9A7B1C] border border-[#D4AF37]/50 text-xs font-bold">
                Order Reference: {orderSuccessRecord.reference}
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35]">
                JazakAllah Khair, {orderSuccessRecord.customerName}!
              </h1>
              <p className="text-sm sm:text-base text-[#252525]/80 max-w-xl mx-auto">
                Your order has been recorded in our system. Tap the green WhatsApp button below if
                WhatsApp did not open automatically so our team can confirm your dispatch.
              </p>
            </div>

            {/* Receipt Summary */}
            <div className="rounded-2xl bg-[#FFF9EC] border border-[#D4AF37]/45 p-5 space-y-4">
              <div className="flex flex-wrap justify-between gap-2 text-xs text-[#252525]/75 border-b border-[#D4AF37]/30 pb-3">
                <span>
                  <strong>Delivery To:</strong> {orderSuccessRecord.address},{' '}
                  {orderSuccessRecord.city}
                </span>
                <span>
                  <strong>Payment:</strong> {orderSuccessRecord.paymentMethod}
                </span>
              </div>

              <div className="space-y-2">
                {orderSuccessRecord.items.map((item) => (
                  <div key={item.key} className="flex justify-between text-sm">
                    <span>
                      {item.name} ({item.weight}) × {item.quantity}
                    </span>
                    <span className="font-semibold text-[#064B35]">
                      {formatPKR(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-[#D4AF37]/30 flex justify-between items-baseline">
                <span className="font-bold text-[#064B35]">Total Payable on Delivery</span>
                <span className="font-extrabold text-xl text-[#064B35]">
                  {formatPKR(orderSuccessRecord.total)}
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                type="button"
                onClick={() =>
                  openWhatsAppWithMessage(buildConfirmedOrderWhatsAppMessage(orderSuccessRecord))
                }
                className="flex-1 py-4 px-6 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-[#062E22] font-extrabold text-sm shadow-md flex items-center justify-center gap-2 transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Send Order Confirmation on WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => navigateTo('home')}
                className="py-4 px-6 rounded-xl bg-[#064B35] text-[#FFF9EC] font-bold text-sm"
              >
                Back to Home
              </button>
            </div>
          </div>
        </div>
      );
    }

    if (cart.length === 0) {
      return (
        <div className="max-w-xl mx-auto px-4 py-16 text-center space-y-4">
          <h2 className="font-serif text-2xl font-bold text-[#064B35]">
            Your Cart is Empty
          </h2>
          <p className="text-sm text-[#252525]/75">
            Add your favorite snacks before proceeding to checkout.
          </p>
          <button
            type="button"
            onClick={() => navigateTo('shop', { category: 'All' })}
            className="px-6 py-3 rounded-xl bg-[#064B35] text-[#FFF9EC] text-sm font-bold"
          >
            Go to Shop
          </button>
        </div>
      );
    }

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        <div className="mb-8">
          <button
            type="button"
            onClick={() => navigateTo('cart')}
            className="text-xs font-bold text-[#9A7B1C] hover:underline mb-2 inline-block"
          >
            ← Back to Cart
          </button>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#064B35]">
            Complete Your Order
          </h1>
          <p className="text-sm text-[#252525]/75 mt-1">
            Fast Cash on Delivery checkout with instant WhatsApp order confirmation.
          </p>
        </div>

        <form onSubmit={handlePlaceOrder} noValidate className="grid lg:grid-cols-12 gap-8 items-start">
          {/* Customer Delivery Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/45 shadow-sm space-y-5">
            <h2 className="font-serif text-2xl font-bold text-[#064B35] border-b border-[#D4AF37]/25 pb-3">
              Delivery Information
            </h2>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                Customer Full Name *
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Enter your full name"
                className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
              />
              {errors.customerName && (
                <p className="text-xs text-red-600 mt-1 font-medium">{errors.customerName}</p>
              )}
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0300-1234567"
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
                />
                {errors.phone && (
                  <p className="text-xs text-red-600 mt-1 font-medium">{errors.phone}</p>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#064B35]">
                    WhatsApp Number *
                  </label>
                  <label className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#9A7B1C] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sameAsPhone}
                      onChange={(e) => setSameAsPhone(e.target.checked)}
                      className="accent-[#064B35]"
                    />
                    <span>Same as Phone</span>
                  </label>
                </div>
                <input
                  type="tel"
                  disabled={sameAsPhone}
                  value={sameAsPhone ? phone : whatsapp}
                  onChange={(e) => setWhatsapp(e.target.value)}
                  placeholder="0300-1234567"
                  className={`w-full px-4 py-3 rounded-xl border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm ${
                    sameAsPhone ? 'bg-gray-100 text-gray-500' : 'bg-[#FFF9EC]/60'
                  }`}
                />
                {errors.whatsapp && (
                  <p className="text-xs text-red-600 mt-1 font-medium">{errors.whatsapp}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                City *
              </label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm font-medium"
              >
                {PAKISTAN_CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              {errors.city && (
                <p className="text-xs text-red-600 mt-1 font-medium">{errors.city}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                Complete Delivery Address *
              </label>
              <textarea
                rows={3}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="House / Flat #, Street, Block / Sector, Nearest Landmark"
                className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
              />
              {errors.address && (
                <p className="text-xs text-red-600 mt-1 font-medium">{errors.address}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                Order Notes (Optional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Preferred delivery time, gift note, or rider instructions..."
                className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC]/60 border border-[#D4AF37]/45 focus:border-[#064B35] focus:outline-none text-sm"
              />
            </div>

            {/* Payment Method Selection */}
            <div className="pt-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-2.5">
                Payment Method
              </label>
              <div className="space-y-2.5">
                <label className="flex items-center justify-between p-4 rounded-2xl border-2 border-[#064B35] bg-[#FFF9EC] cursor-pointer">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'Cash on Delivery'}
                      onChange={() => setPaymentMethod('Cash on Delivery')}
                      className="accent-[#064B35] w-4 h-4"
                    />
                    <div>
                      <div className="font-bold text-sm text-[#064B35]">
                        Cash on Delivery (COD)
                      </div>
                      <div className="text-xs text-[#252525]/75">
                        Pay in cash when your Aroma Foods parcel arrives at your doorstep.
                      </div>
                    </div>
                  </div>
                  <Truck className="w-5 h-5 text-[#064B35]" />
                </label>

                {storeConfig.bankTransferEnabled && (
                  <label className="flex items-start justify-between p-4 rounded-2xl border border-[#D4AF37]/50 bg-white cursor-pointer">
                    <div className="flex items-start gap-3">
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={paymentMethod === 'Bank Transfer'}
                        onChange={() => setPaymentMethod('Bank Transfer')}
                        className="accent-[#064B35] w-4 h-4 mt-1"
                      />
                      <div>
                        <div className="font-bold text-sm text-[#064B35]">Direct Bank Transfer</div>
                        <div className="text-xs text-[#252525]/75 mt-1">
                          {storeConfig.bankDetailsPlaceholder}
                        </div>
                      </div>
                    </div>
                    <CreditCard className="w-5 h-5 text-[#9A7B1C] shrink-0" />
                  </label>
                )}
              </div>
            </div>
          </div>

          {/* Right Order Summary */}
          <div className="lg:col-span-5 rounded-3xl bg-white p-6 sm:p-7 border-2 border-[#D4AF37]/60 shadow-md space-y-5">
            <h2 className="font-serif text-2xl font-bold text-[#064B35]">Your Order</h2>

            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div
                  key={item.key}
                  className="flex items-center justify-between gap-3 text-sm pb-3 border-b border-[#D4AF37]/20"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-12 h-12 rounded-lg object-cover border border-[#D4AF37]/30"
                    />
                    <div>
                      <div className="font-bold text-[#064B35]">{item.name}</div>
                      <div className="text-xs text-[#252525]/70">
                        {item.weight} × {item.quantity}
                      </div>
                    </div>
                  </div>
                  <div className="font-bold text-[#064B35]">
                    {formatPKR(item.price * item.quantity)}
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-2 text-sm pt-1">
              <div className="flex justify-between text-[#252525]/80">
                <span>Subtotal</span>
                <span className="font-semibold">{formatPKR(cartSubtotal)}</span>
              </div>
              <div className="flex justify-between text-[#252525]/80">
                <span>Delivery Charges</span>
                <span className="font-semibold text-[#064B35]">
                  {deliveryCharge === 0 ? 'FREE' : formatPKR(deliveryCharge)}
                </span>
              </div>
              <div className="flex justify-between items-baseline pt-3 border-t border-[#D4AF37]/35">
                <span className="font-bold text-base text-[#064B35]">Total Price</span>
                <span className="font-extrabold text-2xl text-[#064B35]">
                  {formatPKR(cartGrandTotal)}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 px-6 rounded-xl bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] font-bold text-base border border-[#D4AF37] shadow-lg flex items-center justify-center gap-2 transition-all"
            >
              <CheckCircle2 className="w-5 h-5 text-[#D4AF37]" />
              <span>{isSubmitting ? 'Saving Order...' : 'Place Order & Confirm on WhatsApp'}</span>
            </button>

            <p className="text-[11px] text-center text-[#252525]/65 leading-relaxed">
              Clicking Place Order saves your order reference and opens WhatsApp with your
              pre-filled summary for swift dispatch confirmation.
            </p>
          </div>
        </form>
      </div>
    );
  };

  // ==========================================================================
  // RENDER: SECURE ADMIN DASHBOARD
  // ==========================================================================
  const AdminDashboardView = () => {
    const [passcodeInput, setPasscodeInput] = useState('');
    const [loginError, setLoginError] = useState('');
    const [adminTab, setAdminTab] = useState('overview'); // overview | products | orders | categories | settings | inquiries

    // Product Form State (Add / Edit)
    const [editingProduct, setEditingProduct] = useState(null);
    const [prodForm, setProdForm] = useState({
      name: '',
      category: categories[0]?.name || 'Nimko',
      shortTag: '',
      description: '',
      ingredientsPlaceholder: '',
      image: FOOD_IMAGES.nimkoSpecial,
      inStock: true,
      isBestSeller: false,
      weightsText: '250g:300, 500g:560, 1kg:1080'
    });

    // Category Form
    const [newCatName, setNewCatName] = useState('');
    const [newCatDesc, setNewCatDesc] = useState('');

    // Settings Form
    const [settingsDraft, setSettingsDraft] = useState(storeConfig);
    const [newAdminPass, setNewAdminPass] = useState('');

    useEffect(() => {
      setSettingsDraft(storeConfig);
    }, [storeConfig]);

    const handleAdminLogin = (e) => {
      e.preventDefault();
      const storedHash =
        localStorage.getItem(STORAGE_KEYS.ADMIN_PASS_HASH) || DEFAULT_ADMIN_HASH;
      if (simpleHash(passcodeInput.trim()) === storedHash) {
        sessionStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
        setIsAdminAuthenticated(true);
        setLoginError('');
        setPasscodeInput('');
        showToast('Admin Authenticated', 'Welcome to Aroma Foods Management Portal.');
      } else {
        setLoginError('Invalid administrator access key. Please verify your passcode.');
      }
    };

    const handleAdminLogout = () => {
      sessionStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
      setIsAdminAuthenticated(false);
      showToast('Logged Out', 'Admin session ended.');
    };

    if (!isAdminAuthenticated) {
      return (
        <div className="max-w-md mx-auto px-4 py-16 sm:py-24">
          <div className="rounded-3xl bg-white p-8 border-2 border-[#D4AF37]/60 shadow-xl space-y-6">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-[#064B35] text-[#D4AF37] flex items-center justify-center mx-auto border border-[#D4AF37]">
                <Lock className="w-7 h-7" />
              </div>
              <h1 className="font-serif text-2xl font-bold text-[#064B35]">
                Aroma Foods Admin Portal
              </h1>
              <p className="text-xs text-[#252525]/75 leading-relaxed">
                Protected merchant area for managing products, PKR prices, stock availability,
                customer orders, and WhatsApp settings.
              </p>
            </div>

            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#064B35] mb-1.5">
                  Administrator Access Key
                </label>
                <input
                  type="password"
                  value={passcodeInput}
                  onChange={(e) => setPasscodeInput(e.target.value)}
                  placeholder="Enter admin passcode"
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 focus:border-[#064B35] focus:outline-none text-sm"
                  required
                />
                {loginError && (
                  <p className="text-xs text-red-600 mt-1.5 font-medium">{loginError}</p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-5 rounded-xl bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] font-bold text-sm border border-[#D4AF37] shadow-md transition-all"
              >
                Unlock Dashboard
              </button>
            </form>

            <div className="p-3.5 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/40 text-[11px] text-[#252525]/80 leading-relaxed">
              <strong>Setup Note:</strong> For local preview testing, use the setup passcode
              documented in the delivery guide (<code className="font-mono">aroma2026</code>), then
              update it under <em>Settings</em> before production deployment with Supabase Auth.
            </div>
          </div>
        </div>
      );
    }

    // Parse weights string like "250g:300, 500g:560"
    const parseWeightsString = (str) => {
      const pairs = str
        .split(',')
        .map((part) => part.trim())
        .filter(Boolean);
      const parsed = pairs
        .map((pair) => {
          const [label, priceStr] = pair.split(':').map((s) => s.trim());
          const price = Number(priceStr);
          if (!label || isNaN(price) || price <= 0) return null;
          return { label, price };
        })
        .filter(Boolean);
      return parsed.length > 0 ? parsed : [{ label: '250g', price: 300 }];
    };

    const startEditProduct = (prod) => {
      setEditingProduct(prod);
      setProdForm({
        name: prod.name,
        category: prod.category,
        shortTag: prod.shortTag || '',
        description: prod.description,
        ingredientsPlaceholder: prod.ingredientsPlaceholder || '',
        image: prod.image,
        inStock: prod.inStock,
        isBestSeller: prod.isBestSeller,
        weightsText: prod.weights.map((w) => `${w.label}:${w.price}`).join(', ')
      });
    };

    const resetProdForm = () => {
      setEditingProduct(null);
      setProdForm({
        name: '',
        category: categories[0]?.name || 'Nimko',
        shortTag: '',
        description: '',
        ingredientsPlaceholder: '',
        image: FOOD_IMAGES.nimkoSpecial,
        inStock: true,
        isBestSeller: false,
        weightsText: '250g:300, 500g:560, 1kg:1080'
      });
    };

    const handleImageUpload = (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setProdForm((prev) => ({ ...prev, image: reader.result }));
          showToast('Image Loaded', 'Product photo preview updated.');
        }
      };
      reader.readAsDataURL(file);
    };

    const handleSaveProduct = (e) => {
      e.preventDefault();
      if (!prodForm.name.trim()) {
        showToast('Name Required', 'Please enter a product name.');
        return;
      }
      const weights = parseWeightsString(prodForm.weightsText);

      if (editingProduct) {
        setProducts((prev) =>
          prev.map((p) =>
            p.id === editingProduct.id
              ? {
                  ...p,
                  name: prodForm.name.trim(),
                  category: prodForm.category,
                  shortTag: prodForm.shortTag.trim() || prodForm.category,
                  description: prodForm.description.trim(),
                  ingredientsPlaceholder: prodForm.ingredientsPlaceholder.trim(),
                  image: prodForm.image || FOOD_IMAGES.nimkoSpecial,
                  inStock: prodForm.inStock,
                  isBestSeller: prodForm.isBestSeller,
                  weights
                }
              : p
          )
        );
        showToast('Product Updated', `${prodForm.name} saved.`);
      } else {
        const newProd = {
          id: 'prod-' + Date.now(),
          name: prodForm.name.trim(),
          category: prodForm.category,
          shortTag: prodForm.shortTag.trim() || prodForm.category,
          description:
            prodForm.description.trim() || 'Freshly packed traditional Pakistani snack.',
          ingredientsPlaceholder:
            prodForm.ingredientsPlaceholder.trim() ||
            '[Placeholder: Add verified ingredients list]',
          image: prodForm.image || FOOD_IMAGES.nimkoSpecial,
          inStock: prodForm.inStock,
          isBestSeller: prodForm.isBestSeller,
          weights
        };
        setProducts((prev) => [newProd, ...prev]);
        showToast('Product Added', `${newProd.name} added to storefront.`);
      }
      resetProdForm();
    };

    const handleDeleteProduct = (id) => {
      setProducts((prev) => prev.filter((p) => p.id !== id));
      if (editingProduct?.id === id) resetProdForm();
      showToast('Product Deleted', 'Removed from catalog.');
    };

    const toggleProductStock = (id) => {
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, inStock: !p.inStock } : p))
      );
    };

    const toggleProductBestSeller = (id) => {
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, isBestSeller: !p.isBestSeller } : p))
      );
    };

    const handleUpdateOrderStatus = (orderId, newStatus) => {
      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, status: newStatus } : o))
      );
      showToast('Order Status Updated', `Marked as ${newStatus}`);
    };

    const handleAddCategory = (e) => {
      e.preventDefault();
      if (!newCatName.trim()) return;
      if (categories.some((c) => c.name.toLowerCase() === newCatName.trim().toLowerCase())) {
        showToast('Category Exists', 'That category name is already present.');
        return;
      }
      setCategories((prev) => [
        ...prev,
        {
          id: 'cat-' + Date.now(),
          name: newCatName.trim(),
          tagline: 'Custom Category',
          description: newCatDesc.trim() || 'Traditional Pakistani specialty selection.',
          badge: 'New'
        }
      ]);
      setNewCatName('');
      setNewCatDesc('');
      showToast('Category Added', `${newCatName.trim()} is now live.`);
    };

    const handleSaveSettings = (e) => {
      e.preventDefault();
      setStoreConfig(settingsDraft);
      if (newAdminPass.trim().length >= 6) {
        localStorage.setItem(STORAGE_KEYS.ADMIN_PASS_HASH, simpleHash(newAdminPass.trim()));
        setNewAdminPass('');
      }
      showToast('Settings Saved', 'Storefront & WhatsApp configuration updated.');
    };

    const totalRevenue = orders
      .filter((o) => o.status !== 'Cancelled')
      .reduce((sum, o) => sum + o.total, 0);

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Top Admin Header */}
        <div className="rounded-3xl bg-[#064B35] text-[#FFF9EC] p-6 sm:p-8 border-2 border-[#D4AF37] shadow-lg mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-[0.22em] text-[#D4AF37]">
              Merchant Control Center
            </span>
            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-white mt-1">
              Aroma Foods Admin Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-[#FFF9EC]/80 mt-1">
              All changes saved here immediately update the live storefront.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => navigateTo('home')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-[#D4AF37]/50"
            >
              View Live Storefront
            </button>
            <button
              type="button"
              onClick={handleAdminLogout}
              className="px-4 py-2.5 rounded-xl bg-red-600/90 hover:bg-red-600 text-white text-xs font-bold inline-flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6">
          {[
            { id: 'overview', label: 'Overview', icon: LayoutDashboard },
            { id: 'products', label: `Products (${products.length})`, icon: Box },
            { id: 'orders', label: `Orders (${orders.length})`, icon: ShoppingCart },
            { id: 'categories', label: `Categories (${categories.length})`, icon: Filter },
            { id: 'inquiries', label: `Messages (${inquiries.length})`, icon: Mail },
            { id: 'settings', label: 'WhatsApp & Store Settings', icon: Settings }
          ].map((tab) => {
            const Icon = tab.icon;
            const active = adminTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setAdminTab(tab.id)}
                className={`shrink-0 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold inline-flex items-center gap-2 border transition-all ${
                  active
                    ? 'bg-[#064B35] text-[#FFF9EC] border-[#064B35] shadow'
                    : 'bg-white text-[#252525] border-[#D4AF37]/40 hover:border-[#064B35]'
                }`}
              >
                <Icon className="w-4 h-4 text-[#D4AF37]" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW */}
        {adminTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="rounded-2xl bg-white p-5 border border-[#D4AF37]/45 shadow-sm">
                <div className="text-xs font-bold uppercase text-[#9A7B1C]">Total Order Value</div>
                <div className="font-serif text-2xl sm:text-3xl font-bold text-[#064B35] mt-1">
                  {formatPKR(totalRevenue)}
                </div>
              </div>
              <div className="rounded-2xl bg-white p-5 border border-[#D4AF37]/45 shadow-sm">
                <div className="text-xs font-bold uppercase text-[#9A7B1C]">Customer Orders</div>
                <div className="font-serif text-2xl sm:text-3xl font-bold text-[#064B35] mt-1">
                  {orders.length}
                </div>
              </div>
              <div className="rounded-2xl bg-white p-5 border border-[#D4AF37]/45 shadow-sm">
                <div className="text-xs font-bold uppercase text-[#9A7B1C]">Active Products</div>
                <div className="font-serif text-2xl sm:text-3xl font-bold text-[#064B35] mt-1">
                  {products.filter((p) => p.inStock).length} / {products.length}
                </div>
              </div>
              <div className="rounded-2xl bg-white p-5 border border-[#D4AF37]/45 shadow-sm">
                <div className="text-xs font-bold uppercase text-[#9A7B1C]">WhatsApp Line</div>
                <div className="font-mono text-sm sm:text-base font-bold text-[#064B35] mt-2 truncate">
                  +{storeConfig.WHATSAPP_NUMBER}
                </div>
              </div>
            </div>

            <div className="rounded-3xl bg-white p-6 border border-[#D4AF37]/45 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-serif text-xl font-bold text-[#064B35]">Recent Orders</h2>
                <button
                  type="button"
                  onClick={() => setAdminTab('orders')}
                  className="text-xs font-bold text-[#9A7B1C] hover:underline"
                >
                  Manage All Orders →
                </button>
              </div>
              {orders.length === 0 ? (
                <p className="text-sm text-[#252525]/70 py-6 text-center">
                  No customer orders placed yet. Test placing an order from the storefront checkout
                  to see it appear here!
                </p>
              ) : (
                <div className="space-y-3">
                  {orders.slice(0, 5).map((ord) => (
                    <div
                      key={ord.id}
                      className="p-4 rounded-2xl bg-[#FFF9EC] border border-[#D4AF37]/35 flex flex-wrap items-center justify-between gap-3"
                    >
                      <div>
                        <div className="font-bold text-sm text-[#064B35]">
                          {ord.reference} — {ord.customerName} ({ord.city})
                        </div>
                        <div className="text-xs text-[#252525]/75">
                          {ord.items.length} item(s) • {formatPKR(ord.total)} • {ord.paymentMethod}
                        </div>
                      </div>
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#064B35] text-[#F3E5AB]">
                        {ord.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: PRODUCTS MANAGEMENT */}
        {adminTab === 'products' && (
          <div className="grid lg:grid-cols-12 gap-8 items-start">
            {/* Add / Edit Form */}
            <form
              onSubmit={handleSaveProduct}
              className="lg:col-span-5 rounded-3xl bg-white p-6 border border-[#D4AF37]/50 shadow-sm space-y-4"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-serif text-xl font-bold text-[#064B35]">
                  {editingProduct ? `Edit: ${editingProduct.name}` : 'Add New Product'}
                </h2>
                {editingProduct && (
                  <button
                    type="button"
                    onClick={resetProdForm}
                    className="text-xs font-semibold text-red-600 hover:underline"
                  >
                    Cancel Edit
                  </button>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-[#064B35] mb-1">Product Name *</label>
                <input
                  type="text"
                  required
                  value={prodForm.name}
                  onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })}
                  placeholder="e.g. Kashmiri Mix Nimko"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#064B35] mb-1">Category</label>
                  <select
                    value={prodForm.category}
                    onChange={(e) => setProdForm({ ...prodForm, category: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-sm"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#064B35] mb-1">Badge Tag</label>
                  <input
                    type="text"
                    value={prodForm.shortTag}
                    onChange={(e) => setProdForm({ ...prodForm, shortTag: e.target.value })}
                    placeholder="e.g. Fresh Batch"
                    className="w-full px-3 py-2.5 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#064B35] mb-1">
                  Weights & PKR Prices (Format: weight:price, ...)
                </label>
                <input
                  type="text"
                  value={prodForm.weightsText}
                  onChange={(e) => setProdForm({ ...prodForm, weightsText: e.target.value })}
                  placeholder="250g:300, 500g:560, 1kg:1080"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-sm font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#064B35] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={prodForm.description}
                  onChange={(e) => setProdForm({ ...prodForm, description: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#064B35] mb-1">
                  Ingredients / Label Notes
                </label>
                <input
                  type="text"
                  value={prodForm.ingredientsPlaceholder}
                  onChange={(e) =>
                    setProdForm({ ...prodForm, ingredientsPlaceholder: e.target.value })
                  }
                  className="w-full px-3.5 py-2 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#064B35] mb-1">
                  Product Photo (URL or Upload File)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={prodForm.image}
                    onChange={(e) => setProdForm({ ...prodForm, image: e.target.value })}
                    placeholder="https://..."
                    className="flex-1 px-3 py-2 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-xs"
                  />
                  <label className="px-3 py-2 rounded-xl bg-[#064B35] text-[#FFF9EC] text-xs font-bold cursor-pointer inline-flex items-center gap-1 shrink-0">
                    <Upload className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Upload</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div className="flex items-center gap-6 pt-1">
                <label className="inline-flex items-center gap-2 text-xs font-bold text-[#064B35] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={prodForm.inStock}
                    onChange={(e) => setProdForm({ ...prodForm, inStock: e.target.checked })}
                    className="accent-[#064B35]"
                  />
                  <span>In Stock</span>
                </label>
                <label className="inline-flex items-center gap-2 text-xs font-bold text-[#064B35] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={prodForm.isBestSeller}
                    onChange={(e) =>
                      setProdForm({ ...prodForm, isBestSeller: e.target.checked })
                    }
                    className="accent-[#064B35]"
                  />
                  <span>Featured Best Seller</span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-5 rounded-xl bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] font-bold text-sm border border-[#D4AF37]"
              >
                {editingProduct ? 'Save Product Changes' : 'Add Product to Catalog'}
              </button>
            </form>

            {/* Product Inventory List */}
            <div className="lg:col-span-7 space-y-3">
              {products.map((prod) => (
                <div
                  key={prod.id}
                  className="rounded-2xl bg-white p-4 border border-[#D4AF37]/40 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5">
                    <img
                      src={prod.image}
                      alt={prod.name}
                      className="w-16 h-16 rounded-xl object-cover border border-[#D4AF37]/30 shrink-0"
                    />
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-serif font-bold text-base text-[#064B35]">
                          {prod.name}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-[#FFF9EC] text-[#9A7B1C] font-bold border border-[#D4AF37]/30">
                          {prod.category}
                        </span>
                      </div>
                      <div className="text-xs text-[#252525]/75 mt-1">
                        {prod.weights.map((w) => `${w.label}: ${formatPKR(w.price)}`).join(' | ')}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => toggleProductStock(prod.id)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold border ${
                        prod.inStock
                          ? 'bg-emerald-50 text-[#064B35] border-emerald-200'
                          : 'bg-red-50 text-red-700 border-red-200'
                      }`}
                    >
                      {prod.inStock ? 'In Stock' : 'Out of Stock'}
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleProductBestSeller(prod.id)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-bold border ${
                        prod.isBestSeller
                          ? 'bg-[#D4AF37]/25 text-[#0B3D2E] border-[#D4AF37]'
                          : 'bg-gray-50 text-gray-500 border-gray-200'
                      }`}
                      title="Toggle Homepage Best Seller"
                    >
                      ★ Best
                    </button>

                    <button
                      type="button"
                      onClick={() => startEditProduct(prod)}
                      className="p-2 rounded-lg bg-[#FFF9EC] text-[#064B35] border border-[#D4AF37]/40 hover:bg-[#064B35] hover:text-white"
                      title="Edit Product"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDeleteProduct(prod.id)}
                      className="p-2 rounded-lg bg-red-50 text-red-600 hover:bg-red-600 hover:text-white"
                      title="Delete Product"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: ORDERS MANAGEMENT */}
        {adminTab === 'orders' && (
          <div className="space-y-4">
            {orders.length === 0 ? (
              <div className="rounded-3xl bg-white p-12 text-center border border-[#D4AF37]/40">
                <h3 className="font-serif text-xl font-bold text-[#064B35]">
                  No Customer Orders Yet
                </h3>
                <p className="text-sm text-[#252525]/75 mt-1">
                  Orders submitted via the Checkout page appear here automatically with full customer
                  info and status controls.
                </p>
              </div>
            ) : (
              orders.map((ord) => (
                <div
                  key={ord.id}
                  className="rounded-3xl bg-white p-6 border border-[#D4AF37]/45 shadow-sm space-y-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#D4AF37]/25 pb-4">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-sm font-extrabold text-[#064B35] bg-[#FFF9EC] px-3 py-1 rounded-lg border border-[#D4AF37]/50">
                          {ord.reference}
                        </span>
                        <span className="text-xs text-[#252525]/60">
                          {new Date(ord.createdAt).toLocaleString()}
                        </span>
                      </div>
                      <h3 className="font-serif text-xl font-bold text-[#064B35] mt-2">
                        {ord.customerName} — {ord.city}
                      </h3>
                      <p className="text-xs sm:text-sm text-[#252525]/80 mt-0.5">
                        Phone: <strong>{ord.phone}</strong> | WhatsApp:{' '}
                        <strong>{ord.whatsapp}</strong>
                      </p>
                      <p className="text-xs sm:text-sm text-[#252525]/80">
                        Address: {ord.address}
                      </p>
                      {ord.notes && (
                        <p className="text-xs text-[#9A7B1C] mt-1">Note: {ord.notes}</p>
                      )}
                    </div>

                    <div className="flex flex-col sm:items-end gap-2">
                      <label className="text-[11px] font-bold uppercase text-[#9A7B1C]">
                        Order Status
                      </label>
                      <select
                        value={ord.status}
                        onChange={(e) => handleUpdateOrderStatus(ord.id, e.target.value)}
                        className="px-3.5 py-2 rounded-xl bg-[#064B35] text-[#FFF9EC] text-xs font-bold border border-[#D4AF37]"
                      >
                        {ORDER_STATUSES.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() => {
                          const custDigits = ord.whatsapp.replace(/[^0-9]/g, '');
                          const formattedCust = custDigits.startsWith('0')
                            ? '92' + custDigits.slice(1)
                            : custDigits;
                          const msg = `Assalam-o-Alaikum ${ord.customerName}! Your Aroma Foods order (${ord.reference}) status is currently: *${ord.status}*. Thank you for choosing Taste of Tradition!`;
                          window.open(
                            `https://wa.me/${formattedCust}?text=${encodeURIComponent(msg)}`,
                            '_blank',
                            'noopener,noreferrer'
                          );
                        }}
                        className="px-3.5 py-2 rounded-xl bg-[#25D366]/15 text-[#064B35] hover:bg-[#25D366] text-xs font-bold inline-flex items-center gap-1.5 transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Update Customer on WhatsApp</span>
                      </button>
                    </div>
                  </div>

                  {/* Items Breakdown */}
                  <div className="space-y-1.5">
                    {ord.items.map((item) => (
                      <div key={item.key} className="flex justify-between text-xs sm:text-sm">
                        <span>
                          {item.name} ({item.weight}) × {item.quantity}
                        </span>
                        <span className="font-semibold">
                          {formatPKR(item.price * item.quantity)}
                        </span>
                      </div>
                    ))}
                    <div className="pt-2 border-t border-[#D4AF37]/20 flex justify-between font-bold text-sm text-[#064B35]">
                      <span>
                        Total ({ord.paymentMethod} • Delivery:{' '}
                        {ord.deliveryFee === 0 ? 'FREE' : formatPKR(ord.deliveryFee)})
                      </span>
                      <span>{formatPKR(ord.total)}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 4: CATEGORIES MANAGEMENT */}
        {adminTab === 'categories' && (
          <div className="grid md:grid-cols-12 gap-8 items-start">
            <form
              onSubmit={handleAddCategory}
              className="md:col-span-5 rounded-3xl bg-white p-6 border border-[#D4AF37]/45 shadow-sm space-y-4"
            >
              <h2 className="font-serif text-xl font-bold text-[#064B35]">Add Product Category</h2>
              <div>
                <label className="block text-xs font-bold text-[#064B35] mb-1">
                  Category Name *
                </label>
                <input
                  type="text"
                  required
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder="e.g. Dry Fruits Gift Boxes"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-[#064B35] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newCatDesc}
                  onChange={(e) => setNewCatDesc(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#FFF9EC]/70 border border-[#D4AF37]/45 text-sm"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#064B35] text-[#FFF9EC] text-sm font-bold border border-[#D4AF37]"
              >
                Create Category
              </button>
            </form>

            <div className="md:col-span-7 grid sm:grid-cols-2 gap-4">
              {categories.map((cat) => (
                <div
                  key={cat.id}
                  className="rounded-2xl bg-white p-4 border border-[#D4AF37]/40 shadow-sm flex items-start justify-between gap-2"
                >
                  <div>
                    <h3 className="font-serif font-bold text-lg text-[#064B35]">{cat.name}</h3>
                    <p className="text-xs text-[#252525]/75 mt-1">{cat.description}</p>
                    <div className="text-[11px] font-bold text-[#9A7B1C] mt-2">
                      {products.filter((p) => p.category === cat.name).length} Products
                    </div>
                  </div>
                  {categories.length > 1 && (
                    <button
                      type="button"
                      onClick={() =>
                        setCategories((prev) => prev.filter((c) => c.id !== cat.id))
                      }
                      className="p-1.5 rounded-lg text-red-600 hover:bg-red-50"
                      title="Remove Category"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: CUSTOMER INQUIRIES */}
        {adminTab === 'inquiries' && (
          <div className="space-y-4">
            {inquiries.length === 0 ? (
              <div className="rounded-3xl bg-white p-10 text-center border border-[#D4AF37]/40 text-sm text-[#252525]/75">
                No messages submitted via the Contact page yet.
              </div>
            ) : (
              inquiries.map((inq) => (
                <div
                  key={inq.id}
                  className="rounded-2xl bg-white p-5 border border-[#D4AF37]/40 shadow-sm space-y-2"
                >
                  <div className="flex flex-wrap justify-between gap-2">
                    <span className="font-bold text-sm text-[#064B35]">
                      {inq.name} — {inq.subject}
                    </span>
                    <span className="text-xs text-[#252525]/60">
                      {new Date(inq.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <div className="text-xs text-[#9A7B1C] font-semibold">
                    Phone/WhatsApp: {inq.phone} {inq.email ? `| Email: ${inq.email}` : ''}
                  </div>
                  <p className="text-sm text-[#252525]/85 pt-1">{inq.message}</p>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 6: STORE & WHATSAPP SETTINGS */}
        {adminTab === 'settings' && (
          <form
            onSubmit={handleSaveSettings}
            className="max-w-3xl rounded-3xl bg-white p-6 sm:p-8 border border-[#D4AF37]/50 shadow-sm space-y-5"
          >
            <h2 className="font-serif text-2xl font-bold text-[#064B35]">
              WhatsApp & Storefront Configuration
            </h2>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-[#064B35] mb-1">
                  Business WhatsApp Number (International format, no +)
                </label>
                <input
                  type="text"
                  value={settingsDraft.WHATSAPP_NUMBER}
                  onChange={(e) =>
                    setSettingsDraft({ ...settingsDraft, WHATSAPP_NUMBER: e.target.value })
                  }
                  placeholder="923001234567"
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 text-sm font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-[#064B35] mb-1">
                  Display Phone Number
                </label>
                <input
                  type="text"
                  value={settingsDraft.phonePlaceholder}
                  onChange={(e) =>
                    setSettingsDraft({ ...settingsDraft, phonePlaceholder: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 text-sm"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-[#064B35] mb-1">
                  Business Email
                </label>
                <input
                  type="text"
                  value={settingsDraft.emailPlaceholder}
                  onChange={(e) =>
                    setSettingsDraft({ ...settingsDraft, emailPlaceholder: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-[#064B35] mb-1">
                  Business Address
                </label>
                <input
                  type="text"
                  value={settingsDraft.addressPlaceholder}
                  onChange={(e) =>
                    setSettingsDraft({ ...settingsDraft, addressPlaceholder: e.target.value })
                  }
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 text-sm"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase text-[#064B35] mb-1">
                  Standard Delivery Fee (PKR)
                </label>
                <input
                  type="number"
                  value={settingsDraft.deliveryFee}
                  onChange={(e) =>
                    setSettingsDraft({ ...settingsDraft, deliveryFee: Number(e.target.value) })
                  }
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-[#064B35] mb-1">
                  Free Delivery Above (PKR)
                </label>
                <input
                  type="number"
                  value={settingsDraft.freeDeliveryThreshold}
                  onChange={(e) =>
                    setSettingsDraft({
                      ...settingsDraft,
                      freeDeliveryThreshold: Number(e.target.value)
                    })
                  }
                  className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 text-sm"
                />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#FFF9EC] border border-[#D4AF37]/40 space-y-3">
              <label className="inline-flex items-center gap-2 text-sm font-bold text-[#064B35] cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsDraft.bankTransferEnabled}
                  onChange={(e) =>
                    setSettingsDraft({
                      ...settingsDraft,
                      bankTransferEnabled: e.target.checked
                    })
                  }
                  className="accent-[#064B35]"
                />
                <span>Enable Bank Transfer Option on Checkout</span>
              </label>

              {settingsDraft.bankTransferEnabled && (
                <input
                  type="text"
                  value={settingsDraft.bankDetailsPlaceholder}
                  onChange={(e) =>
                    setSettingsDraft({
                      ...settingsDraft,
                      bankDetailsPlaceholder: e.target.value
                    })
                  }
                  placeholder="Bank Name, Account Title, IBAN"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-[#D4AF37]/50 text-xs"
                />
              )}
            </div>

            <div>
              <label className="block text-xs font-bold uppercase text-[#064B35] mb-1">
                Update Admin Passcode (Optional, min 6 chars)
              </label>
              <input
                type="password"
                value={newAdminPass}
                onChange={(e) => setNewAdminPass(e.target.value)}
                placeholder="Leave blank to keep current access key"
                className="w-full px-4 py-3 rounded-xl bg-[#FFF9EC] border border-[#D4AF37]/50 text-sm"
              />
            </div>

            <button
              type="submit"
              className="px-8 py-4 rounded-xl bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] font-bold text-sm border border-[#D4AF37] shadow-md"
            >
              Save All Store Settings
            </button>
          </form>
        )}
      </div>
    );
  };

  // ==========================================================================
  // RENDER: QUICK CART DRAWER & SEARCH MODAL & FLOATING WHATSAPP
  // ==========================================================================
  const renderOverlays = () => (
    <>
      {/* Slide-Over Quick Cart Drawer */}
      {cartDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/55 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#FFF9EC] h-full shadow-2xl border-l-2 border-[#D4AF37] flex flex-col">
            <div className="p-5 bg-[#064B35] text-[#FFF9EC] flex items-center justify-between border-b border-[#D4AF37]/50">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
                <h2 className="font-serif text-xl font-bold">Your Snack Bag ({cartItemCount})</h2>
              </div>
              <button
                type="button"
                onClick={() => setCartDrawerOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/10 text-[#FFF9EC]"
                aria-label="Close Cart Drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.length === 0 ? (
                <div className="py-16 text-center space-y-3">
                  <p className="font-serif text-lg font-bold text-[#064B35]">Your bag is empty</p>
                  <p className="text-xs text-[#252525]/70">
                    Add fresh Nimko, Chana, Daal, or Khajoor pouches to get started.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setCartDrawerOpen(false);
                      navigateTo('shop', { category: 'All' });
                    }}
                    className="px-5 py-2.5 rounded-xl bg-[#064B35] text-[#FFF9EC] text-xs font-bold"
                  >
                    Browse Products
                  </button>
                </div>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.key}
                    className="rounded-2xl bg-white p-3.5 border border-[#D4AF37]/40 flex items-center gap-3 shadow-xs"
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 rounded-xl object-cover border border-[#D4AF37]/30 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-serif font-bold text-sm text-[#064B35] truncate">
                        {item.name}
                      </h4>
                      <div className="text-xs text-[#9A7B1C] font-semibold">
                        {item.weight} • {formatPKR(item.price)}
                      </div>
                      <div className="mt-2 flex items-center justify-between">
                        <div className="inline-flex items-center rounded-lg border border-[#D4AF37]/50 bg-[#FFF9EC]">
                          <button
                            type="button"
                            onClick={() => updateCartQuantity(item.key, -1)}
                            className="p-1.5 text-[#064B35]"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2.5 text-xs font-bold">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => updateCartQuantity(item.key, 1)}
                            className="p-1.5 text-[#064B35]"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <span className="font-bold text-sm text-[#064B35]">
                          {formatPKR(item.price * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-5 bg-white border-t border-[#D4AF37]/40 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-[#252525]/75">Subtotal</span>
                  <span className="font-bold text-[#064B35]">{formatPKR(cartSubtotal)}</span>
                </div>
                <div className="flex justify-between text-xs text-[#9A7B1C]">
                  <span>Delivery</span>
                  <span>{deliveryCharge === 0 ? 'FREE' : formatPKR(deliveryCharge)}</span>
                </div>
                <div className="flex justify-between font-extrabold text-base text-[#064B35] pt-2 border-t border-[#D4AF37]/25">
                  <span>Total</span>
                  <span>{formatPKR(cartGrandTotal)}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setCartDrawerOpen(false);
                      navigateTo('cart');
                    }}
                    className="py-3 px-3 rounded-xl bg-[#FFF9EC] text-[#064B35] border border-[#064B35] text-xs font-bold"
                  >
                    View Full Cart
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCartDrawerOpen(false);
                      navigateTo('checkout');
                    }}
                    className="py-3 px-3 rounded-xl bg-[#064B35] text-[#FFF9EC] border border-[#D4AF37] text-xs font-bold"
                  >
                    Checkout (COD)
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleCartWhatsAppOrder}
                  className="w-full py-3 px-4 rounded-xl bg-[#25D366] text-[#062E22] font-extrabold text-xs flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Order via WhatsApp</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Search Modal */}
      {searchModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center pt-16 sm:pt-24 px-4">
          <div className="w-full max-w-xl rounded-3xl bg-[#FFF9EC] border-2 border-[#D4AF37] shadow-2xl overflow-hidden">
            <div className="p-4 bg-[#064B35] text-[#FFF9EC] flex items-center gap-3">
              <Search className="w-5 h-5 text-[#D4AF37]" />
              <input
                type="text"
                autoFocus
                value={shopSearchQuery}
                onChange={(e) => setShopSearchQuery(e.target.value)}
                placeholder="Type snack name (e.g. Special Nimko, Besan Chana, Khajoor)..."
                className="flex-1 bg-transparent text-white placeholder-[#FFF9EC]/60 focus:outline-none text-sm"
              />
              <button
                type="button"
                onClick={() => setSearchModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 max-h-80 overflow-y-auto space-y-2">
              {products
                .filter(
                  (p) =>
                    !shopSearchQuery.trim() ||
                    p.name.toLowerCase().includes(shopSearchQuery.toLowerCase()) ||
                    p.category.toLowerCase().includes(shopSearchQuery.toLowerCase())
                )
                .slice(0, 6)
                .map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleSelectProduct(p.id)}
                    className="w-full text-left p-2.5 rounded-xl bg-white hover:bg-[#064B35] hover:text-white border border-[#D4AF37]/35 flex items-center justify-between gap-3 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-11 h-11 rounded-lg object-cover"
                      />
                      <div>
                        <div className="font-serif font-bold text-sm">{p.name}</div>
                        <div className="text-[11px] opacity-75">{p.category}</div>
                      </div>
                    </div>
                    <div className="text-xs font-bold text-[#9A7B1C] group-hover:text-[#D4AF37]">
                      From {formatPKR(p.weights[0]?.price || 0)}
                    </div>
                  </button>
                ))}

              <button
                type="button"
                onClick={() => navigateTo('shop')}
                className="w-full py-2.5 text-center text-xs font-bold text-[#064B35] hover:underline"
              >
                View All Results in Shop →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating WhatsApp Concierge Button */}
      <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2">
        {whatsappPopoverOpen && (
          <div className="w-72 rounded-2xl bg-white border-2 border-[#D4AF37] shadow-2xl overflow-hidden animate-fade-in">
            <div className="p-3.5 bg-[#064B35] text-[#FFF9EC] flex items-center justify-between">
              <div>
                <div className="font-serif font-bold text-sm">Aroma Foods WhatsApp</div>
                <div className="text-[10px] text-[#D4AF37]">Taste of Tradition • Quick Order</div>
              </div>
              <button
                type="button"
                onClick={() => setWhatsappPopoverOpen(false)}
                className="text-white/80 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-3.5 space-y-2.5 text-xs">
              <p className="text-[#252525]/80">
                Assalam-o-Alaikum! How can we assist with your traditional snack order today?
              </p>
              <button
                type="button"
                onClick={() =>
                  openWhatsAppWithMessage(
                    `Assalam-o-Alaikum Aroma Foods!\n\nI would like to place an order.\n\nProduct: [Product Name]\nWeight: [Selected Weight]\nQuantity: [Quantity]\n\nCustomer Name: [Name]\nDelivery Address: [Address]\nCity: [City]\n\nPlease confirm my order.`
                  )
                }
                className="w-full py-2.5 px-3 rounded-xl bg-[#25D366] text-[#062E22] font-extrabold flex items-center justify-center gap-1.5"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Start WhatsApp Order</span>
              </button>
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={() => setWhatsappPopoverOpen((o) => !o)}
          className="h-14 px-5 rounded-full bg-[#064B35] hover:bg-[#0B3D2E] text-[#FFF9EC] border-2 border-[#D4AF37] shadow-2xl flex items-center gap-2.5 transition-transform hover:scale-105"
          aria-label="Order on WhatsApp"
        >
          <span className="w-8 h-8 rounded-full bg-[#25D366] text-[#062E22] flex items-center justify-center">
            <MessageCircle className="w-5 h-5" />
          </span>
          <span className="font-bold text-xs sm:text-sm pr-1">WhatsApp Order</span>
        </button>
      </div>

      {/* Non-Blocking Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 sm:left-6 sm:translate-x-0 z-50 max-w-sm w-[92%] sm:w-auto rounded-2xl bg-[#064B35] text-[#FFF9EC] px-4 py-3.5 border border-[#D4AF37] shadow-2xl flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0" />
          <div className="text-xs">
            <div className="font-bold text-white">{toastMessage.title}</div>
            {toastMessage.subtitle && (
              <div className="text-[#FFF9EC]/80 mt-0.5">{toastMessage.subtitle}</div>
            )}
          </div>
        </div>
      )}
    </>
  );

  // ==========================================================================
  // RENDER: PROFESSIONAL FOOTER
  // ==========================================================================
  const renderFooter = () => (
    <footer className="bg-[#0B3D2E] text-[#FFF9EC] border-t-2 border-[#D4AF37] mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Brand Column */}
          <div className="lg:col-span-4 space-y-4">
            <AromaLogo variant="dark" />
            <p className="text-xs sm:text-sm text-[#FFF9EC]/80 leading-relaxed max-w-sm">
              Bringing the authentic taste of traditional Pakistani snacks, roasted pulses, and
              hand-selected Khajoor to your home in hygienic, resealable emerald & gold pouches.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              {Object.entries(storeConfig.socialLinks).map(([name, href]) => (
                <a
                  key={name}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-[#D4AF37] hover:text-[#0B3D2E] text-xs font-semibold capitalize transition-colors"
                >
                  {name}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-serif text-base font-bold text-[#D4AF37]">Navigation</h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#FFF9EC]/85">
              <li>
                <button type="button" onClick={() => navigateTo('home')} className="hover:text-[#D4AF37]">
                  Home
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('shop', { category: 'All' })}
                  className="hover:text-[#D4AF37]"
                >
                  Shop All
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigateTo('about')} className="hover:text-[#D4AF37]">
                  About Us
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigateTo('contact')} className="hover:text-[#D4AF37]">
                  Contact Us
                </button>
              </li>
              <li>
                <button type="button" onClick={() => navigateTo('cart')} className="hover:text-[#D4AF37]">
                  Shopping Cart
                </button>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-base font-bold text-[#D4AF37]">Snack Categories</h4>
            <ul className="grid grid-cols-2 gap-2 text-xs sm:text-sm text-[#FFF9EC]/85">
              {categories.map((cat) => (
                <li key={cat.id}>
                  <button
                    type="button"
                    onClick={() => navigateTo('shop', { category: cat.name })}
                    className="hover:text-[#D4AF37] text-left"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Placeholders */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-base font-bold text-[#D4AF37]">Get in Touch</h4>
            <div className="space-y-2.5 text-xs text-[#FFF9EC]/80">
              <div className="flex items-start gap-2">
                <MessageCircle className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>WhatsApp: +{storeConfig.WHATSAPP_NUMBER}</span>
              </div>
              <div className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{storeConfig.phonePlaceholder}</span>
              </div>
              <div className="flex items-start gap-2">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{storeConfig.emailPlaceholder}</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{storeConfig.addressPlaceholder}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-[#D4AF37]/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#FFF9EC]/70">
          <div>
            © {new Date().getFullYear()} AROMA FOODS — Taste of Tradition. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Cash on Delivery Across Pakistan</span>
            <span>•</span>
            <button
              type="button"
              onClick={() => navigateTo('admin')}
              className="text-[#D4AF37] hover:underline font-semibold inline-flex items-center gap-1"
            >
              <Lock className="w-3 h-3" />
              <span>Admin Portal</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );

  // ==========================================================================
  // ROOT LAYOUT SHELL
  // ==========================================================================
  return (
    <div
      className="min-h-screen flex flex-col text-[#252525] selection:bg-[#064B35] selection:text-[#F3E5AB]"
      style={{
        backgroundColor: '#FFF9EC',
        fontFamily: "'Plus Jakarta Sans', 'Inter', system-ui, -apple-system, sans-serif"
      }}
    >
      {/* Editorial Serif & Sans Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
        .font-serif {
          font-family: 'Playfair Display', Georgia, serif;
        }
      `}</style>

      {renderNavbar()}

      <main className="flex-1">
        {activePage === 'home' && renderHomePage()}
        {activePage === 'shop' && renderShopPage()}
        {activePage === 'product' && <ProductDetailsView />}
        {activePage === 'about' && renderAboutPage()}
        {activePage === 'contact' && <ContactPageView />}
        {activePage === 'cart' && renderCartPage()}
        {activePage === 'checkout' && <CheckoutPageView />}
        {activePage === 'admin' && <AdminDashboardView />}
      </main>

      {renderFooter()}
      {renderOverlays()}
    </div>
  );
}