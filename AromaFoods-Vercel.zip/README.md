# Aroma Foods website

This is the complete React project for the Aroma Foods shop.

## Before publishing

Open `src/App.jsx` and update the sample prices and any business details that still show placeholders. The WhatsApp order number is already set to **+92 324 6500970**. Product photos load from image hosting websites, so visitors need an internet connection to see them.

## Publish on Vercel

1. Create a free GitHub account if you do not already have one.
2. Create a new GitHub repository and upload the contents of this project folder. Keep `package.json`, `index.html`, and `vercel.json` at the top level.
3. Sign in to Vercel with GitHub, select **Add New → Project**, and import this repository.
4. Keep the detected framework as **Vite**. Vercel uses `npm run build` and `dist` as the output folder; deploy the project.
5. Open the Vercel link it gives you to check the live site.

## Run on your computer

Install Node.js, open a terminal in this folder, then run:

```sh
npm install
npm run dev
```

Vite will print a local address to open in your browser. To create a production build, run `npm run build`.
